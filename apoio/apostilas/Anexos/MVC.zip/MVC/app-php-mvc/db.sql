create table clientes(
id int primary key auto_increment,
nome varchar(50),
idade int
);

insert into clientes(nome, idade) values ('Pedro', 48),
('Jorge', 26),
('Marta', 35),
('João', 21);

