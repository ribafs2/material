    <br><br>
    <hr>
    <footer class="text-center">
        Encontre em <a href="https://github.com/ribafs/simplest-mvc">Aplicativo Simples PHP com MVC</a>.
    </footer>
</body>
</html>
