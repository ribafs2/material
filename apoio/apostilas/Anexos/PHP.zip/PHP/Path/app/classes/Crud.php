<?php

// Relativo
require_once '../conexao.php';

print '<hr>';

// Absoluto
require '/var/www/html/app/conexao.php';

