<!DOCTYPE html>
<html lang="pt">
<head>
    <title>CRUD Full</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="assetc/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assetc/css/style.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
    .panel-footer {
        padding: 0;
        background: none;
    }
    </style>
</head>
