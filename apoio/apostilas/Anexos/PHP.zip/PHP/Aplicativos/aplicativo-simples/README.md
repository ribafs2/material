# Aplicativo simples, com dois CRUDs e um menu inicial

## Com alguns recursos como:
- Paginação
- Busca
- Bootstrap

Partindo do app-auto


