<?php
require_once('./header_root.php');
?>

<br><br><br>
<style>
hr{
    display:none;
}
</style>
<div class="container cabecalho">
    <h1 align="center">Aplicativo com CRUDs Automáticos</h1>
</div>
	<div align="center">

<h3><a href="clientes">Clientes</a></h3>
<h3><a href="produtos">Produtos</a></h3>

	</div>
</div>
<br><br><br>
<?php require_once('./footer.php'); ?>

