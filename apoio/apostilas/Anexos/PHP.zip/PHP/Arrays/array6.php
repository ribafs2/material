<?php

  /*** create an array ***/
  $animals = array('dingo', 'wombat', 'Steve Irwin', 'playpus', 'emu');

  /*** show the first member of the array ***/
  echo $animals[1];
