<?php

 /*** create an array ***/
 $animals = array('dingo', 'wombat', 'Steve Irwin', 'playpus', 'emu');

 /*** dump the array contents ***/
print '<pre>';
 print_r( $animals );
 
?> 
