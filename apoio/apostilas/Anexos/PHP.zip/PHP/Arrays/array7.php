<?php

  /*** turn on error reporting ***/
  error_reporting(E_ALL);

  /*** create an array ***/
  $animals = array('dingo', 'wombat', 'Steve Irwin', 'playpus', 'emu');

  /*** show the eighth member of the array ***/
  echo $animals[8];
