<?php

 /*** create an array ***/
 $animals = array( 'dingo', 'wombat', 'Steve Irwin', 'playpus', 'emu' );

 /*** show the count of members in the array ***/
 echo count( $animals );

 echo '<br />';

 /*** show the size of the array ***/
 echo sizeof( $animals );
