<?php
// create a string
$string = 'big';

// Search for a match
echo preg_match("/b[aoiu]g/", $string, $matches);

?> 
