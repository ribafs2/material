# CRUD simples

Apenas para mostrar as operações básicas de um CRUD usando PHP com PDO


