<?php

namespace Mvc\View;

class ClientesView
{
	public function index(){
		return 'View de Clientes';
	}
}
