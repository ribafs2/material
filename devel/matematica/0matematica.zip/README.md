# Matemática na programação

Dicas para PHP, JavaScript, Java, etc

- Equação do segundo grau
- Plotagem
- Gráficos
- MMC
- MDC
- Outros

