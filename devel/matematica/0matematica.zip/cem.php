<?php

	for ($i = 1; $i <= 100; $i++){

        if($i % 5 == 0){
    	    printf("Número %d\n<br>", $i);
        }else{
    	    printf("Número %d", $i);
        }    
    }

