Curiosidades matemáticas

Acesse o Google e entre com

y = x^2

y = -x^2

https://www.prof-edigleyalexandre.com/2011/12/construa-graficos-de-funcoes.html

https://www.prof-edigleyalexandre.com/2012/04/7-softwares-que-todo-professor-de.html

https://www.wolframalpha.com/

https://www.wolframalpha.com/examples/mathematics/

https://www.solarsystemscope.com/

https://m3.ime.unicamp.br/

https://sorisomail.com/partilha/74120.html (Veja com o Edge ou Chrome)

- http://dir.by/developer/js/math/?lang=eng
- https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math
- https://www.adammarcwilliams.co.uk/animating-javascript-trigonometry/
- https://www.chartjs.org/
- https://d3js.org
- https://jsxgraph.org/
- https://iamsjy17.github.io/plotta.js-page/


