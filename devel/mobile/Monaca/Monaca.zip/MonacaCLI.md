# Monaca CLI

## Instalação do Monaca CLI

sudo npm install -g monaca

## Logar com o servidor na nuvem

Entre com e-mail e senha

monaca login

## Criando um novo projeto

monaca create PROJECT_DIRECTORY

monaca create breakout

Selecionar a categoria usando as setas para baixo e para cima e enter para confirmar:

? Choose a category: (Use arrow keys: ↑ ↓ →)
❯ JavaScript 
  Onsen UI and AngularJS 
  Onsen UI and Angular 
  Onsen UI and React 
  Onsen UI and Vue.js 
  No Framework 
  Sample Apps 

No Framework

Selecionar o template

? Choose a category: No Framework
? Select a template - Press P to see a preview (Use arrow keys: ↑ ↓ ← →)
❯ Blank 

Blank

Aguarde o download do tempalte blank

Após concluir mostra

Project is created successfully.

Type "cd brekout" and run monaca command again.
  > monaca preview      => Run app in the browser
  > monaca debug        => Run app in the device using Monaca Debugger
  > monaca remote build => Start remote build for iOS/Android/Windows
  > monaca upload       => Upload this project to Monaca Cloud IDE

cd breakout

run preview - abrirá automaticamente no navegador


