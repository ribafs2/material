# Alfabeto em Português

## Áudio

Baixei o som das letras.

## Imagens

Baixei as letras em um único arquivo e separei cada uma. Como os arquivos são bem grandes eu redimensionei cada um, usando o Kolourpaint, com largura de 80 pixel e deixando a altura livre mantendo a proporcionalidade.

## Pasta

Criei a pasta AlfabetoBr e copiei para dentro o áudio e as imagens.

## O jogo

### Criar um novo projeto

- Abrir o GDevelop
- Mudar o idioma para Português brasileiro, para facilitar
File
Language
Português brasileiro
Fechar

Arquivo - Criar - Novo projeto em branco ou Teclar Ctrl+Alt+N

### Configurar o projeto/jogo

- Clicar no Gerenciador de projetos
- Configurações do Jogo
- Propriedades
    Nome do jogo - Alfabeto em português
    Descrição do jogo - Jogo em que o usuário pressiona uma tecla ou clica em uma letra e o seu som é emitido.
    Autores - ribafs
    Empacotamento - br.net.ribamar.alfabetobr (domínio invertido mais o nome do jogo. Pode ser fictício)
    Nome do editor - Ribamar (usado quando o jogo for enviado para as lojas)
    Resolução e renderização - 800 x 650
    Modo de redimensionamento - Sem mudanças no tamanho do jogo
    Aplicar
    Arquivos do projeto - Vários arquivos, salvos na pasta ao lado do arquivo principal

### Renomear a cena default

- Clicar no Gerenciador de projetos
- Clicar nos 3 pontos à direita de Untitled scene
    Renomear
    Inicial
    Teclar enter
    Clicar em Inicial



