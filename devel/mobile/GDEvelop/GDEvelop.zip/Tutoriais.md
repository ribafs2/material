# Alguns tutoriais oficiais

## Plataforma

https://wiki.gdevelop.io/gdevelop5/tutorials/platformer/start

## Sapce Shooter

https://wiki.gdevelop.io/gdevelop5/tutorials/space-shooter

## Eventos

https://wiki.gdevelop.io/gdevelop5/events

## Outros

https://wiki.gdevelop.io/gdevelop5/start


