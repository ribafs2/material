# Eventos

Cada eventos tem uma causa/condition e um efeito/action.

Quando uma causa age um efeito acontece.

O GDevelop tem uma grande quantidade pronta de conditions e actions. É importante conhecê-las.

Caso não seja especificada a condição a ação acontecerá em todos os frames.

Agora vamos adicionar um botão/personagem e um texto

O texto com name texto: Ainda não clicou

O personagem com nome jogador.

Clicar em jogador e em Events

Adicionar um novo evento:

Condition - Mouse button is pressed

Action - Clicar no objeto texto e em Modify the test = e Agora clicou

Adicionar um segundo evento

Condition - Key is pressed - Space

Action - Clicar no objeto texto e em Modify the test = e Espaço pressionado

Visutalizar. Clicar no jogador e teclar espaço


Caso criemos um evento apenas com a ação ela acontecerá em todos fps da cena.


