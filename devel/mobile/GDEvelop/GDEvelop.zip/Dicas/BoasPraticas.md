# Boas práticas

Nomes dos objetos, funções e propriedades em CamelCase

Ex: CenaInicial

Isso é uma boa prática e facilita a leitura


