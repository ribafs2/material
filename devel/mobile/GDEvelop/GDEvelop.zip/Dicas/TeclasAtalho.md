# Customizar as teclas de atalho default

No meu caso já tenho a combinação

Ctrl+Alt+N que conflita com Alt+Ctrl+N default do GDevelop para criar um novo projeto

Então abro o GDevelop e clico em

File - Preferences - Keyboard Shortcuts

Clico em Create a new project

Clico a direita em Alt + Ctrl + N e atribuo nova combinação

Salvar o jogo/projeto - Ctrl+S

Ctrl+Q - Fechar projeto

F4 - Visualizar

Ctrl+P - command pallete


