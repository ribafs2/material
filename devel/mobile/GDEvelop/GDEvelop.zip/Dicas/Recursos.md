# Recursos Básicos

Quando criamos um projeto em branco no GDevelop 5-5 ele nos entraga uma cena vazia.

A cena é a tela onde acontece o jogo.

Podemos adicionar objetos na cena

Ao selecionar um objeto podemos adicionar eventos para ele e ações que serão executadas quando acontecem os eventos.

Este é o princípio básico dos jogos no GDevelop


Z-order - quanto maior mais na frente. 0 fica no fundo.
