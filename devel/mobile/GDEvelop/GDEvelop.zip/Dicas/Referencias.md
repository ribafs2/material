# Links sobre o GDevelop e de vídeo aulas

https://gdevelop.io/

https://wiki.gdevelop.io/

https://gdevelop.io/features

https://gdevelop.io/blog

https://gdevelop.io/page/contribute

https://gdevelop.io/game-example

https://gdevelop.io/academy

https://gdevelop.io/page/javascript-game-engine

https://gdevelop.io/page/gdevelop-for-game-studios-indies-and-education

https://github.com/GDevelopApp

https://github.com/4ian/GDevelop/releases

https://www.youtube.com/@GDevelopApp

https://www.youtube.com/watch?v=k1-Bdb5Y0C8&list=PL3YlZTdKiS88w1pAJbm78OfgnsMv90ucs

https://www.facebook.com/GDevelopApp

https://twitter.com/GDevelopApp

https://liluo.io/ - Liluo.io é o lugar para descobrir e jogar, diretamente do seu navegador, os melhores jogos feitos com GDevelop.

https://www.youtube.com/watch?v=Zct5wYuqWcQ&list=PLRwRR3G4X_NyKkD9aVJ_FWlhghFx3zfxG

https://www.youtube.com/watch?v=za-PtWFrTjE&list=PLRwRR3G4X_NzVCFa5a4z8wxuXZTAXOwWk

https://www.youtube.com/watch?v=7-IyN-VUlzM&list=PLRwRR3G4X_NzvXg5qYtKq9g57qXXWpmDW

https://www.youtube.com/watch?v=jHnEFxLPxTs&list=PL8nOkcD8Ra7LHyGBVN0uwgjqNyBeSWG6G&index=2

https://www.youtube.com/watch?v=P9kq-3sIi0I

https://www.youtube.com/watch?v=jKhZKnHn7Gw

https://www.youtube.com/watch?v=4NKsp1jjHBo&list=PL5yED1H1NPE974KuGDV9x-fnetlx5XZJf

Jogo de paltaforma - 5 aulas - https://www.youtube.com/watch?v=nruYwsIw84A&list=PLluSsg_QQhQwT2IIXp31vo8JcGRQtLi3v

https://www.youtube.com/watch?v=qF2JLKgb3Mo

https://www.youtube.com/watch?v=9lICBDO9rGU&list=PLRwRR3G4X_NwMZRPEqvwrEKLUxFoMl5vM

https://www.youtube.com/watch?v=UTqa_r5zp_4&list=PLRwRR3G4X_NwpGC--YW7DqdmkXzOdfcNl

https://www.youtube.com/watch?v=loq28jLJQyY&list=PLRwRR3G4X_NyD1fohw4LM_kXoPBBSY6MF

https://www.youtube.com/watch?v=-lQHcVMfFfY&list=PLRwRR3G4X_NxCYTfR14x4jkN7yApE_8wp

https://www.youtube.com/watch?v=Zct5wYuqWcQ&list=PLRwRR3G4X_NyKkD9aVJ_FWlhghFx3zfxG

https://www.youtube.com/watch?v=7-IyN-VUlzM&list=PLRwRR3G4X_NzvXg5qYtKq9g57qXXWpmDW

https://www.youtube.com/watch?v=LQqk_gTubyI&list=PLRwRR3G4X_Nyn1IA4v0mcDcaQ8Kf1Mnjb

https://www.youtube.com/watch?v=xEU9aKKzp7E&list=PLRwRR3G4X_NwJDmZfu8j75G2KABpcJZIM

https://www.youtube.com/watch?v=StZhjL1j7wY&list=PLRwRR3G4X_Nwxd8RT95p2wW9jQ7wy7fIG

https://www.youtube.com/watch?v=za-PtWFrTjE&list=PLRwRR3G4X_NzVCFa5a4z8wxuXZTAXOwWk

https://www.youtube.com/watch?v=aJjXSfdoKRQ&list=PLRwRR3G4X_NzPMVV1Lmtve3w55G2wl5vc

https://www.youtube.com/watch?v=EkgJQ2UtbDQ&list=PL5yED1H1NPE9jjFJWvmCiw_Mrn7_LzLDp

https://www.youtube.com/watch?v=VArTWOJG-nE&list=PL5yED1H1NPE8wQFTDlYhEmkZYqaSlJbnd

https://www.youtube.com/watch?v=enb1R7xm75U&list=PL5yED1H1NPE8xEdekcQZGS4-e7d22RFpr

https://www.youtube.com/watch?v=jX-qBKhXoEU&list=PL5yED1H1NPE9YCMnwvw3yGm7cpVxG4nYy

https://www.youtube.com/watch?v=jcYemhMBTQs&list=PL5yED1H1NPE_Ut_lDbOZiN6OKDzZv-V3g

https://www.youtube.com/watch?v=9mSmAQC432o&list=PL5yED1H1NPE9Zst5p-Z45vUSSi0vmJn16

https://www.youtube.com/watch?v=J1Ij0uYO-64&list=PL5yED1H1NPE_QRaEUm1EIWDS1y6wY-JYO

https://www.youtube.com/watch?v=W-q72AUdlKE&list=PL5yED1H1NPE-ehu1JRQhwZvL8rOkIDAOb

https://www.youtube.com/watch?v=4NKsp1jjHBo&list=PL5yED1H1NPE974KuGDV9x-fnetlx5XZJf

https://www.youtube.com/watch?v=4NKsp1jjHBo&list=PL5yED1H1NPE-Pf5zSBpc3uyU6ppaBio8g

https://www.youtube.com/watch?v=-khyFEc8aPA&list=PL5yED1H1NPE9ZzuNgk_Estf7Np4g2qA8X

https://www.youtube.com/playlist?list=PLVawTLaO8Js9pSHglVuLzenn2UuHT6AOl

https://www.youtube.com/@CriarUmGame/playlists

Comparando GDevelop com Construct

https://www.youtube.com/watch?v=43IUmwdTqEk

Jogo da velha - 4 aulas

https://www.youtube.com/playlist?list=PL-7vTDfs5G8kv53RWGOTRBcQzN53RaZN9

Criação de jogos - 17 aulas

https://www.youtube.com/playlist?list=PL-7vTDfs5G8lI2TErg_lDfSRqxwaKjlrx


