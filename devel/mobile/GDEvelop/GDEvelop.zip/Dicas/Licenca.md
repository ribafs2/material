# Licença

É um software free e open source

Usando a licença MIT

Pode ser usado para uso pessoal ou comercial sem nenhuma restrição.

Suporta Windows, Mac e Linux e a web.

Exporta para a web, android, ios e windows phone


