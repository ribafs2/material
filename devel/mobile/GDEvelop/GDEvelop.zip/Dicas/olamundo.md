# Criar um projeto tipo Olá Mundo

- Apenas uma cena, a default
- A cena inicial com um pequeno boneco
- Adicionar um texto ao centro: Olá Mundo
- Mudar a cor da cena apra branco: Clicar com botão direito na cena - Open scene properties
- Clicar no botão da cor e digitar FFFFFF e enter e OK

Selecionar o texto e duplo clique nele

Mudar sua cor para FFFFFF e Apply

Assim o texto ficará invisível

Agora selecione o boneco e Eventos

Adicionar uma condição Mouse button pressed - Left

E add uma action 

Selecionar o texto e Change color para 000000

Visualizar e clicar no boneco

Salvar - Ctrl+S


