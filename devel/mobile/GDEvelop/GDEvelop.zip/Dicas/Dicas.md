# Dicas sobre o GDevelop

Caso aconteça de a aba Eventos não aparecer ou seja ocultada, como fazemos para exibir?

- Cliquye no Project manager
- Clique sobre o nome da cena


Versões

Lembre que as diversas versões do GDevelop são diferentes. Precisa tomar cuidado de adaptar quando baixar us fontes de um jogo de versões anteriores.
Exemplificando: na versão anterior e 4 ao criar um projeto novo precisa criar a primeira cena do jogo. Na versão atual, logo que se cria um projeto ele já cria e abre a cena default, o que facilita nossa vida.


