# A colisão é um evento proporcionado pela física.

Máscara de colisão - é a região do objeto que entrará em contato com o outro.

Cada objeto tem uma região ao seu redor e esta região pode ser configurada.

Configurando a máscara de colisão

Duplo clique no objeto

- Edit colision masks
- Use a custom collision mask

Podemos clicar nos pondos dos c antos e arrastar para configurar ou digitar valores nas coordenadas X e Y

Lembrando que idealmente a máscara de colisão deve ser identica ao objeto ou bem próxima.

Observe que acima e à direita temos dois radio buttons:

- Compartilhe as máscaras de colisão para todas as animações
- Compartilhe as máscaras de colisão para todos os sprites desta animação
