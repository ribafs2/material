# Restaurar configurações originais

Tive um problema aqui, onde ocultei o painel lateral esquerdo de propriedades e não consegui mostrar mais.

Então pesquisei e no fórum me deram uma dica

- Remover a pasta /home/ribafs/.config/GDevelop 5

Apenas a removi completamente e ao abrir ele já veio como original, cena ao centro e os paineis a esquerda e a direita.

No windows veja na pasta d seu usuário.

