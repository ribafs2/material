# Introdução

Sempre que começo a ensinar algo eu me cerco da maior quantidade de informações sobre o assunto e procuro ensinar da forma mais fácil possível. Com o GDevelop não foi diferente, mas eu paro por um instante e me lembro que este não é o caminho ideal para ensinar, visto que o principal responsável por qualquer aprendizado não é quem ensina, mas quem aprende. Quem ensina apenas pode facilitar as coisas e quem estuda é o grande responsável e o único que pode garantir o sucesso do aprendizado pra valer. Então é importante ensinar o básico e estimular para que quem estuda se interesse e vá em frente.

O GDevelop é uma ferramenta bem fácil de aprender, mas este fácil é relativo e ninguém pode dizer que é fácil de forma absoluta. É simples relativamente a outroo engines, mas requer estudo, conhecimento, entendimento do motor e muita prática para somente então se conseguir entender. Existem pequenos detalhes escondidos, pequenas nuances que precisam ser percebidas e isso é conseguido com muito estudo e especialmente muita prática.

É uma ferramenta maravilhosa ao meu ver, mas requer trabalho, e trabalho sério para ser dominada.

Um detalhe muito importante que no início não percebemos, pois somos ofuscados pela facilidade de uso e pela enorme quantidade de recursos, é o fato de que é uma ferramenta no-code, que ajuda a criar jogos sem programação, sem código, mas em contrapartida tem limitações e não podemos criar tudo que queremos e da forma que queremos, pelo menos imediatamente. Foi o que eprcebi. Quando programamos com uma linguagem com código e temos conhecimento podemos fazer praticamente qualquer coisa. Mas quando usamos uma ferrementa no-code precisamos conhecer bem a ferramenta e seus recursos e ser muito criativos para conseguir suplantar suas limitações. Se não tem um item usamos outros e assim vamor seguindo.


