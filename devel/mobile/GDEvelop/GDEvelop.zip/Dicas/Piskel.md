# Editor de sprites do GDevelop

Set folder

Resize

Duplicar frame

Vertical Mirror

Iluminação

Layer

Clonar camada

Flip vertical

Importar imagens (pasta - browse images)

Centralizar imagem


