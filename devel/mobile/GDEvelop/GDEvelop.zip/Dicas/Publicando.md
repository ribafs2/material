# Publicação dos jogos

Podemos publicar para:

- Web/HTML 5 (cujo código exportado deve ir para ocupar a pasta do servidor web)
- Para Android ou iOS
- Para PC (Linux, Windows ou Mac)


