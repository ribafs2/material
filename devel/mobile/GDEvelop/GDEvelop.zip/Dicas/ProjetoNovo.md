# Para criar um novo projeto em branco

- Abrir o GDevelop
- File - Create - New empty project
- Project Name - Olá Mundo

Choose folder - indicar a pasta

Create project

Configurar jogo

Clicar no botão azul acima e à esquerda (Project manager)

- Game settings - Properties
- Descrição
- Autor
- Packing - br.net.ribamar.olamundo (caso não tenha um domínio pode usar um gratuito ou até fictício)
- Resolução (lembrar das dimensões onde irá publicar)

Apply

Renomear a cena inicial/default

Clicar no botão Project manager

- Clicar nos 3 pontinhos à direita de Untitled scene e renomear para "menu"

Clicar no botão Project manager

- Clicar em menu

Daqui pra frente seguimos o arquivo Jogo

