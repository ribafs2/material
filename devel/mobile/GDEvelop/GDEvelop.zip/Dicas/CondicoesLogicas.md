# Condições Lógicas

O GDevelop não requer programação, não requer que usemos código, mas precisamos de raciocínio lógico e conhecimento das estruturas de programação ajudam.

Um exemplo é que ele tem condições similares a estruturas lógicas.

AND
OR
NOT
ALLAYS - invertendo fica Nunca

Elas estão em Condições - Avançado - Eventos e fluxo de controle

ADN (E)

Se usarmos o AND ou E num evento com algumas condições as ações serão executadas se e somente se todas as subcondições forem verdadeiras.
Veja que cada uma destas tem a opção: Inverter a condição, que corresponde ao NOT. NOT AND, NOT OR, ...

Subentendido
Se num certo evento temos duas condições para uma única ação, então na prática estamos usando o AND nas condições. Também o mesmo nas ações.


OR(OU)

Se usarmos o OR num evento com algumas condições as ações serão executadas se qualquer das subcondições for verdadeira. Caso nenhuma seja verdadeira não será executada

Trigger once while tru

Sempre que a condição “Acionar uma vez enquanto verdadeiro/Trigger once while tru” for utilizada, as ações do evento serão acionadas apenas uma vez, para cada vez que as condições forem atendidas.

Comparar números

Comparar strings

https://wiki.gdevelop.io/gdevelop5/all-features/advanced-conditions
