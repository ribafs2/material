# Ambiente Linux de Desenvolvimento

O linux trabalha com sistemas de pacotes, onde instalamos o que for necessário dos repositórios da distribuição.

No caso instalaremos os pacotes do Apache com mod_rewrite, PHP com várias extensões, MariaDB, Git, Composer e cia.
Quando aparecer uma nova extensão seremos avisados e atualizaremos. Isso é importante para que sempre tenhamos as novas versões corrigindo problemas das anteriores e trazendo novas funcionalidades.

Para facilitar nosso trabalho na instalação criei um script que faz isso tudo de uma vez. Basta juntar os comandos de instalação de todos os pacotes num script e executá-lo.

Uma outra grande vantagem de usar um desktop Linux é que a grande maioria dos servidores que usam PHP também usam Linux e assim o problema com conflitos de sistema operacional são reduzidosem relação ao Windows.


