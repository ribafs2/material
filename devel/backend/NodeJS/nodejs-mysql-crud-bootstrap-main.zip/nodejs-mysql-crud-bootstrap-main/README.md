# CRUD Nodejs Mysql

- Create database
- Configure in src/app.js
- Import script from database/db.sql
- npm install
- node src/app

## ADD customer 
<p align="center">
	<img src="screenshots/CRUD_ADD.gif" width="570">
</p>

## UPDATE customer
<p align="center">
	<img src="screenshots/CRUD_UPDATE.gif" width="570">
</p>

## DELETE customer 
<p align="center">
	<img src="screenshots/CRUD_DELETE.gif" width="570">
</p>

