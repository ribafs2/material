module.exports = {
    url : 'mongodb://localhost/nodeprac'
};
