module.exports = {
    'facebookAuth': {
        'clientID': 'ID',
        'clientSecret': 'secret',
        'callbackURL': 'http://localhost:8080/auth/facebook/callback'
    },
    'googleAuth': {
        'clientID': 'ID',
        'clientSecret': 'secret',
        'callbackURL': 'http://localhost:8080/auth/google/callback'
    }
};
