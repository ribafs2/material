# nodejs-mysql-crud

Run this project by this command :

1. `npm install`
2. `nodemon src/index.js`
3. `localhost:3000`

#### Screen shot

Home Page

![Home Page](img/home.png "Home Page")

Add New Customer

![Add New Customer](img/add.png "Add New Customer")
