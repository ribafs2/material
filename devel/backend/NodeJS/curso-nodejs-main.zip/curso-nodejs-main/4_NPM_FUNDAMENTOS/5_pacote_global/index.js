// npm link lodash
const _ = require('lodash')

const arr = [1, 2, 2, 3, 4, 5, 6, 6, 7, 8, 8]

console.log(_.sortedUniq(arr))
