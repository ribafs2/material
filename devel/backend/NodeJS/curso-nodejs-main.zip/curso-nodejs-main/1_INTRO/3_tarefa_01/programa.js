const a = 10;
const b = 5;

console.log(a + b);
