REPL Terminal

• Read − Reads user's input, parses the input into JavaScript data-structure, and stores in memory.
• Eval − Takes and evaluates the data structure.
• Print − Prints the result.
• Loop − Loops the above command until the user presses ctrl-c twice.

O node tem uma console acessada executando no terminal

node

Aceita operações matemáticas e o uso do console.log e outros

Comandos

• ctrl + c − terminate the current command.
• ctrl + c twice − terminate the Node REPL.
• ctrl + d − terminate the Node REPL.
• Up/Down Keys − see command history and modify previous commands.
• tab Keys − list of current commands.
• .help − list of all commands.
• .break − exit from multiline expression.
• .clear − exit from multiline expression.
• .save �lename − save the current Node REPL session to a �le.
• .load �lename − load �le content in current Node REPL session.

Sair - Ctrl+C duas vezes


