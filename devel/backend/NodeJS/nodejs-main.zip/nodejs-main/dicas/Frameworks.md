# Frameworks para nodejs

NestJS -- Framework backend
https://nestjs.com/

Express - framework web
https://expressjs.com/pt-br/

Hapl
https://hapi.dev/

Sails
https://sailsjs.com/

Socket.io
https://socket.io/

Meteor
https://www.meteor.com/

Koa
https://koajs.com/

Total
https://www.totaljs.com/

Feather
https://feathersjs.com/

Loopback
https://loopback.io/

Adonis - MVC framework
https://adonisjs.com/

Derby
https://derbyjs.com/

https://technostacks.com/blog/nodejs-frameworks/

