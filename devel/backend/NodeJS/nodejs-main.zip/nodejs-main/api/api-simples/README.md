API lendo do arquivo data.json

npm install

node server

http://127.0.0.1:3000/clients

http://127.0.0.1:3000/clients/5


