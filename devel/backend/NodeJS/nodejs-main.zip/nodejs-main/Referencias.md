https://www.youtube.com/playlist?list=PLzehOqhpwpxjs8bfI72dR-wV-7ZGxfuTN

https://www.youtube.com/playlist?list=PLJ_KhUnlXUPtbtLwaxxUxHqvcNQndmI4B

https://www.youtube.com/watch?v=Ql6F6wPphkA&list=PLJ_KhUnlXUPtbtLwaxxUxHqvcNQndmI4B&index=23

https://stackify.com/learn-nodejs-tutorials/

https://nodejs.dev/pt/

https://flaviocopes.com/access/

https://flaviocopes.com/books-dist/express-handbook.pdf

https://flaviocopes.com/books-dist/js-handbook.pdf

https://flaviocopes.com/books-dist/node-handbook.pdf

https://books.goalkicker.com/

https://books.goalkicker.com/NodeJSBook/

https://books.goalkicker.com/MySQLBook/

https://books.goalkicker.com/MongoDBBook/

https://books.goalkicker.com/TypeScriptBook2/

https://books.goalkicker.com/JavaScriptBook/

