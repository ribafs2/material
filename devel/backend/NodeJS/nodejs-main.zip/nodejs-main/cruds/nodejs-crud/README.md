# Testar

- npm install (caso apareça mensagem de erro Missing script: "build", ignore)
- Crie um banco
- Importe o script db.sql
- Configure em lib/db.js
- node index
- Segure o Ctrl e clique no link ao final para abrir o aplicativo


![]('./crud2.png')
