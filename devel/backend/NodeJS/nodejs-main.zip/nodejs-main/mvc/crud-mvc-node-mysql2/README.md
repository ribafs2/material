# CRUD MVC

- Crie um banco
- Importe o script db.sql para ele
- Configure em src/database/dbConfig..js
- Execute
npm install (ignore erros de build)
node src/index (no raiz)

![]('img/mvc.png')
