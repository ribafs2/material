const mysqlConfig = {
  host:"localhost",
  user:"root",
  password:"root",
  port:3306,
  database:"testes"
}

module.exports = mysqlConfig
