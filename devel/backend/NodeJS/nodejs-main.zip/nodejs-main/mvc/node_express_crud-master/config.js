var config={
    database:{
        host:'localhost',
        user :'root',
        password:'root',
        database:'testes'
    }
}
module.exports=config;
