# NODE EXPRESS CRUD MVC
A demo of node crud to show the MVC architecture.
Using Node js, Express, MySQL and EJS templating engine.

Author : Smit Mehta

- Crie um banc
- Importe o db.sql para ele

Execute
npm install (ignore erro com build)
noode index


![]('img/mvc3.png')
