É um ORM que facilita a conexão e o gerenciamento de banco de dados

npm install --save sequelize

npm install --save mysql2

