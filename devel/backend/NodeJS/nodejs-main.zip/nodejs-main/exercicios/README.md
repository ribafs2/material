# Dicas sobre NodeJS

Alguns pequenos exercícios sobre NodeJS, abordando vários assuntos:

- Módulos
- Filesystem
- HTTP
- MySQL
- Hello World
- E outros
