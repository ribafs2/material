
https://www.w3schools.com/nodejs/

https://stackoverflow.com/questions/57865931/exporting-a-module-for-creating-connection-creates-multiple-connection-in-nodejs

Mais sobre node com MySQL:

https://www.w3schools.com/nodejs/nodejs_mysql_orderby.asp

Node com MongoDb

https://www.w3schools.com/nodejs/nodejs_mongodb.asp

https://www.w3schools.com/nodejs/ref_modules.asp

https://www.tutorialspoint.com/nodejs/


