function soma(a,b){
    return a + b
}

function sub(a,b){
    return b - a
}

function multi(a,b){
    return a * b
}

function div(a,b){
    return a / b
}

console.log(sub(2,4))

