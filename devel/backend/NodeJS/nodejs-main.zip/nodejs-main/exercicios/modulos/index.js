var express = require("express")
var app = express()

ou, idealmente
const express = require("express")
const app = express()

//A função abaixo precisa ser a última linha do script
app.listen(8081)


