
// Criando módulos e usando
exports.meuModulo = function () {
  return Date();
}; 

