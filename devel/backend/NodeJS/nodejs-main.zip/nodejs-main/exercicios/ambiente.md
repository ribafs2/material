# Ambiente simples de desenvolvimento com Node

## Criar uma pasta

mkdir exercicios

cd exercicios

## Instalar o Noode

Instalar o node no sistema opepracional

## Abrir o VSCode nesta

code.

Agora criaremos os arquivos node diretamente na pasta ou no VSCode.

É uma boa ideia usar o terminal integrado do VSCode para executar os arquivos com (Exemplo: arquivo.js)

node arquivo


Nodemon (node-mon) reinicia o servidor automaticamente a cada alteração no código

sudo npm install nodemon -g

nodemon

Agora ao invés de executar os projetos com node executar com nodemon, exemplo:

nodemon app.js


