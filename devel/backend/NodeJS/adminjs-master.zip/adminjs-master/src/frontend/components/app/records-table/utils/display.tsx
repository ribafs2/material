export const display = (isTitle: boolean): Array<string> => [
  isTitle ? 'table-cell' : 'none',
  isTitle ? 'table-cell' : 'none',
  'table-cell',
  'table-cell',
]
