/* eslint-disable import/prefer-default-export */
import Edit from './edit'

export {
  Edit as edit,
}
