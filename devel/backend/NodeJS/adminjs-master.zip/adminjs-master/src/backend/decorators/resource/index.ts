export { default as ResourceDecorator } from './resource-decorator'
export * from './resource-options.interface'
