export { default as ResourcesFactory } from './resources-factory'
