export { default as BaseProperty, PropertyType } from './base-property'
