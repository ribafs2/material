const DELIMITER = '.'


export { DELIMITER }
