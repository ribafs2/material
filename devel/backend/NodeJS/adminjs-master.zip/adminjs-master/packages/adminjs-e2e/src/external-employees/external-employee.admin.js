const { ExternalEmployees } = require('../../models/index')

/** @type {import('adminjs').ResourceOptions} */
const options = {

}

module.exports = {
  options,
  resource: ExternalEmployees,
}
