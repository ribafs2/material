export interface TagInterface {
  id: string;
  name: string;
}
