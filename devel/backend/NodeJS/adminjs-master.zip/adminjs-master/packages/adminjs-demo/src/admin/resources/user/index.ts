export { UserFeatures as features } from './user-features'
export { UserResource as options } from './user-resource'
export { UserModel as resource } from './entities/sequelize'
