export {
  BlogPostResource as options,
  BlogPostFeatures as features,
} from './blog-post-resource'
export { BlogPostModel as resource } from './entities/sequelize'
