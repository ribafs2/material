export { BrandResource as options } from './brand-resource'
export { BrandModel as resource } from './entities/sequelize'
