export const ContentParent = {
  name: 'Content',
  icon: 'Blog',
}

export const ProductsParent = {
  name: 'Store Management',
  icon: 'InventoryManagement',
}
