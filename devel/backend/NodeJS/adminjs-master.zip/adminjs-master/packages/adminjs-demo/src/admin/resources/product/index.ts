export { ProductResource as options } from './product-resource'
export { ProductModel as resource } from './entities/sequelize'
export { ProductFeatures as features } from './product-features'
