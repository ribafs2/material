import React from 'react'

const ExampleComponent = () => (
  <div>Some example text</div>
)

export default ExampleComponent
