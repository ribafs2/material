# Referências sobre MySQL

https://www.mysqltutorial.org/

https://dev.mysql.com/doc/

https://mariadb.org/documentation/


