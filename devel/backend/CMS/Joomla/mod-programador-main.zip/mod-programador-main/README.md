# mod-programador

Pequeno módulo para o CMS Joomla que mostra uma frase aleatória sobre programação ou motivacional
