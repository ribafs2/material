<?php
/**
* @module Percurso
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @author - Ribamar FS - 04/2016
*/

defined('_JEXEC') or die('Restricted access');

?>
<stong>Este módulo exibe o mapa do Google e traça o percurso no mapa entre dois endereços.</stong>
<a href="modules/mod_percurso_google/percurso.html" target="_blank"><h5>Acessar</h5></a>
