## pensamento-do-dia
## Suporta Joomla 2.5, 3.x e 4.x

Pequeno módulo que mostra um pensamento aleatório a cada visita. São uns 200 pensamentos no total.

## Demo
http://ribafs.org


### Com a compra do GitHub pela (MS) fiz uma cópia deste repositório no GitLab.
https://gitlab.com/ribafs/pensamento-do-dia


## Instalação
https://github.com/ribafs/pensamento-do-dia

