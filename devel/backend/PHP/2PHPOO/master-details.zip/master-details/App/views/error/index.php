<br>
<hr>
<div class="bg-danger text-white">
    <p class="text-center">Esta é a página de erros. Verifique que seu controller ou method não existem.</p>
</div>
