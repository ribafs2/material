# Core

Esta pasta abriga as classes básicas, ou seja, as classes pais.

As classes da pasta App são filhas destas daqui e as extendem.

Em App poderemos ter várias classes filhas de Model: ClientModel, ProductModel, etc.


