# Parâmetros do PDO

Inteiros
PDO::PARAM_INT

Strings
PDO::PARAM_STR

Strings de tamanho 12
PDO::PARAM_STR, 12

Boolean
PDO::PARAM_BOOL

Nulos
PDO::PARAM_NULL


Relação de glyphicons:
https://www.w3schools.com/bootstrap/bootstrap_ref_comp_glyphs.asp
