<!DOCTYPE html>
<html>
<head>
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen"> 
    <link href="css/style.css" rel="stylesheet" media="screen"> 
</head>
<body>
<h1 align="center">CRUD Muito Simples usando PDO</h1>

