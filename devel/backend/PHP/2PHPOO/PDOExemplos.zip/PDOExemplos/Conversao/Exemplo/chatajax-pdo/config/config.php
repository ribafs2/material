<?php
$mysql_host = "localhost";
$mysql_user = "root";
$mysql_pass = "root";
$mysql_db = "testes";
?>
