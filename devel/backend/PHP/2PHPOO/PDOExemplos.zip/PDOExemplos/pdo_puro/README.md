# Este é um exemplo extremamente simples.

Nada de CSS, apenas o CRUD básico com o PDO para mostrar suas funções básicas.

A intenção é a de quando estiver encontrando dificuldade com o uso de funções poder comentar ou excluir a função e substituir pelo respectivo código do CRUD deste exemplo.
