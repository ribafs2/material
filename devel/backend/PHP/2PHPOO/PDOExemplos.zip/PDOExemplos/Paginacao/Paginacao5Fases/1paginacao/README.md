# Controle de Estoque Simplificado em PHP do "zero"

Partindo de um pequeno script de paginação que usa o plugin do jQuery bootpag.

## Nesta fase

Apenas criei a paginação partindo do tutorial original do kodingmadesimple

Crédito pela paginação
https://www.kodingmadesimple.com/2017/01/simple-ajax-pagination-in-jquery-php-pdo-mysql.html

