<?php
/* DATABASE CONFIGURATION */
define('DB_SERVER', 'localhost');
define('DB_DATABASE', 'testes');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'root');

?>
