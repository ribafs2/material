Nesta versão mudei o script de conexão para uma classe
Troquei os arquivos do assets por CDN

