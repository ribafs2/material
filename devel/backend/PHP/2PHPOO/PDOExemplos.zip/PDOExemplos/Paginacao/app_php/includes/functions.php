<?php

// Variáveis
$title = '<a href="../index.php">CRUD com Paginação, PDO, BootStrap e Busca</a>';
$titleMenu = 'CRUD com Paginação, PDO, BootStrap e Busca';
$max_visible = 15;
