# php-pagination
This tutorial explains how to create pagination in PHP 7 and MySQL using the Bootstrap 4 Pagination UI component. Also, learn how to set the dynamic limit in pagination with the session, create prev, next feature, active class in pagination to display results fetched from MySQL database.

[Create Pagination in PHP 7 with MySQL and Bootstrap](https://www.positronx.io/create-pagination-in-php-with-mysql-and-bootstrap/)