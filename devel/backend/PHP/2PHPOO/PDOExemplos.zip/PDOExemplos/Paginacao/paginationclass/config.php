<?php
	//set your database comnfiguration here. Ensure to fill in the username and password if there is any.
	define("DSN","mysql:host=localhost;dbname=testes");
	define("USER","root");
	define("PASS","");
