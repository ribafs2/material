# Classe de Paginação

Em PHP, com PDO e Bootstrap

## Download

https://github.com/ribafs/paginationclass

Descompacte no diretório web

## Crie o banco

E importe o script db.sql para testar. Depois de testar e aprovar então use com seu banco de dados.

## Configuração

config.php

## index.php

Neste arquivo deve entrar com algumas informações: nome da tabela, nomes dos campos que deseja mostrar



