# Paginação

Com busca, PDO e boostrap além de usar OO


## O original é apenas a paginação básica com o bootpag, encontrada neste site:

https://www.kodingmadesimple.com/2017/01/simple-ajax-pagination-in-jquery-php-pdo-mysql.html

Esta fase foi a de converter o código estruturado (crud-estruturado) anterior para um CRUD Orientado a Objetos de forma simples.

Para isso eu parti deste aplicativo:

https://github.com/ribafs/aplicativos-php/tree/master/crud_phpoo

Criei uma pasta classes e criei dentro dela as classes:

- connection.php
- crud.php (apenas com os métodos insert(), update() e delete())

