Nesta versão mudei o script de conexão para uma classe
Troquei os arquivos do assets por CDN

Adicionarei os elementos de um CRUD: add, edit e delete.
