# Paginação com o plugin do jQuery bootpage

## Esta fase 3

Nesta fase estarei adicionando os arquivos header.php e footer.php e os integrando aos arquivos

## Esta fase 2

Troquei os arquivos assets pelo CDN

## Esta fase 1

Apenas moverá as pastas css, js e fonts para a pasta assets e fará os devidos ajustes no arquivo index.php

Este pequeno código (basicamente a paginação) será usado como base para o controle de estoque, passando pelas fases:

- CRUD
- estoque

Terá duas versões, uma com os arquivos assets e outra usando CDN

Este código veio do site

https://www.kodingmadesimple.com/2017/01/simple-ajax-pagination-in-jquery-php-pdo-mysql.html
