Códigos de erro do MySQL
https://phpro.org/articles/MySQL-Error-Codes.html

Códigos de erro do PostgreSQL
https://www.postgresql.org/docs/12/errcodes-appendix.html

Códigos de erro do SQLite
https://www.sqlite.org/c3ref/c_abort.html


