<div class="container">
	<div class="alert alert-info">
    <strong>tutorial link !</strong> <a href="http://cleartuts.blogspot.com/2015/04/php-pdo-crud-tutorial-using-oop-with.html">cleartuts</a>!
	</div>
</div>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
