<?php

require_once 'vendor/autoload.php';

use Cafe\Database;
use Cafe\View;
use Cafe\Controller;

$teste = new Controller;
