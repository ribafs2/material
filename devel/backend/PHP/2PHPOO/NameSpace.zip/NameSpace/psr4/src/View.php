<?php

namespace Cafe;

class View{
    public function __construct(){
        echo 'Olá Page';
    }
}
