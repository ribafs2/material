<?php

namespace Cafe;

class Database{
    public function __construct(){
        echo 'Olá DB';
    }
}
