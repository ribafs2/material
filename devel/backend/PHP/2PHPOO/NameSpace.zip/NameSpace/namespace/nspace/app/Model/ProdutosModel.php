<?php

class ProdutosModel
{
    public function index(){
        return ' index do model de Produtos<br>';
    }
}
