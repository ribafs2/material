<?php

class ProdutosView
{
    public function index(){
        return ' index da view de Produtos<br>';
    }
}
