<?php

namespace Nspace\Model;

class ProdutosModel
{
    public function index(){
        return ' index do model de Produtos<br>';
    }
}
