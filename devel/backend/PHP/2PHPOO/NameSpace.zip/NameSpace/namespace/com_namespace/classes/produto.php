<?php

namespace classes;

class Produto{
    public function mostrarDetalhes(){
        echo 'Detalhes do produto da pasta classes';
    }
}
