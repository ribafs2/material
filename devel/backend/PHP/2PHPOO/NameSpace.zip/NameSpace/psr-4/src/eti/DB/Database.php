<?php

namespace ETI\DB;

class Database
{
    public function getConn()
    {
        return true;
    }
}
