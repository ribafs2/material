<?php

namespace Nms\Model;

class MyModel
{
    public function teste(){
        return 'Model';
    }
}
