<?php
namespace Nms\Controller;

class MyController
{
    public function teste(){
        return 'Controller';
    }
}
