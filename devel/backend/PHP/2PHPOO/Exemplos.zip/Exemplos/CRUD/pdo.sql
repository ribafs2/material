create table produtos(
    id int primary key auto_increment,
    nome varchar(100) not null,
    descricao text
);
