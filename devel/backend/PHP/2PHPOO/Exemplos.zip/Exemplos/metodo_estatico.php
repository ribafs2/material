<?php 
class Estatica
{ 
    
    function teste() 
    { 
        print "Teste de método estático <br>\n"; 
    } 
} 

Estatica::teste();
