<?php

class Testes
{
  public function testes(){
    $this->numRodas = 2;
print '<hr>';
    print $this->numRodas;
  
  }
}
