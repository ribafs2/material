<?php

class Pai
{
    protected $nome = 'Antônio Abreu';
    protected $idade = 48;

    public function __construct(){
        
    }
}
