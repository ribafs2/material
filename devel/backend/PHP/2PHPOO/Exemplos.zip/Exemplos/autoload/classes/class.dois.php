<?php

class Dois{
	public $classe="Dois";
}
