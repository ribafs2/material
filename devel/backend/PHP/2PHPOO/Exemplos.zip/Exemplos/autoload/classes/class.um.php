<?php

class Um{
	public $classe="Um";
}
