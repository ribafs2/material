<?php

class Tres{
	public $classe="Três";
}
