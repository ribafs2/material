<div class="container bg-gray">
    <div align="center">
        Find <a href="https://github.com/panique/mini3">MINI3 on GitHub</a>.
        If you like the mini3 project, support it by <a href="http://tracking.rackspace.com/SH1ES" target="_blank">using Rackspace</a> as your hoster [affiliate link].
    </div>
</div>
</body>
</html>

