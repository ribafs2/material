	<footer class="text-center">
		<p>
			<a href="https://github.com/utoyvo/crud-mvc-oop-pdo" target="_blank">https://github.com/utoyvo/crud-mvc-oop-pdo</a>
			<br>With <span style="color:#f00"><3</span> by <a href="https://github.com/utoyvo" target="_blank">@utoyvo</a>
		</p>
	</footer>
</div><!-- .container -->
</body></html>
