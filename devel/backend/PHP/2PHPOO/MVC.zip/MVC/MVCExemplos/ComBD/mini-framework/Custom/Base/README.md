## Arquivos básicos para a criação de qualquer aplicativo em PHP usando MVC, seguindo o Mini3

composer.json
.htaccess
/public/.htaccess
/public/index.php
/src/config.php
/src/bootstrap.php
/src/Controller
/src/Model
/src/Core/Router
/src/View
/src/templates

Para facilitar já podemos iniciar fazendo uma cópia deste diretório e renomeando para o que desejamos.

