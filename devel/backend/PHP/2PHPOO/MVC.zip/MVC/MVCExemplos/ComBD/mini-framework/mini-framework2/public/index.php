<?php
// FrontController, única entrada para o aplicativo
require __DIR__ . '/../src/bootstrap.php';

