## Mini3 Customização

Ainda procurando simplificar/enender o mini-framework eu agora criei uma versão com apenas a listagem/index de apenas um único CRUD.
Traduzi ainda mais os métodos e propriedades e mudei a tabela para clientes, com os campos id, nome e email.
