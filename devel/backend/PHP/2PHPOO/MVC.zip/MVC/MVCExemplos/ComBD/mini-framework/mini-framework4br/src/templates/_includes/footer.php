<div class="container bg-gray">
    <div align="center">
        <a href="https://github.com/panique/mini3">MINI3 on GitHub</a>.<br>
        Caso tenha gostado do projeto mini3, suporte <a href="http://tracking.rackspace.com/SH1ES" target="_blank">usando Rackspace</a> como sua hospedagem [link afiliado].
    </div>
</div>
</body>
</html>

