<div class="container bg-gray">
    <div align="center">
        Aplicativo criado tendo como base o <a href="https://github.com/panique/mini3">MINI3 adaptado por Ribamar FS</a>.
    </div>
</div>
</body>
</html>

