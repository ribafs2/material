<?php
/**
 * Config
 */
return array(
	'db_driver'   => 'mysql',
	'db_server'   => 'localhost',
	'db_name'     => 'testes',
	'db_username' => 'root',
	'db_password' => 'root',
);
