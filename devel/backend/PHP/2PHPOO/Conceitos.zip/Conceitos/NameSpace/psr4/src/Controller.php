<?php
namespace Cafe;

class Controller{
    public function __construct(){
        echo 'Constructor';
    }
}
