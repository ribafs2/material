<?php
/*
As variáveis de uma classe são chamadas de propriedades. Também chamadas de atributos ou campos.
*/

class pessoa {
	// Uma propriedade (variável)
	private $nome;
}


