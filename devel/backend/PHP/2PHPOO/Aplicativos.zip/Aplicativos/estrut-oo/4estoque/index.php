<?php require_once './header.php' ?>

<div class="container">
    <div class="panel panel-default">
        <div class="panel-heading text-center">
        <h1>Controle de Estoque Simplificado</h1> 







<div class="jumbotron">
        <h3><a href="produtos">Produtos</a> - <a href="compras">Compras</a> - <a href="vendas">Vendas</a> - <a href="estoques">Estoques</a></h3>
</div>

</div>



<?php require_once('./footer.php');?>
