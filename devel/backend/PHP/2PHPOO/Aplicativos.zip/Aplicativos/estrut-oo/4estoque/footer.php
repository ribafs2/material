<div class="container text-center">
    <i>Adaptação de <a href="http://ribafs.github.io" target="_blank">Ribamar FS</a></i>
</div>
<br>
</div>
</div>
</body>
</html>
