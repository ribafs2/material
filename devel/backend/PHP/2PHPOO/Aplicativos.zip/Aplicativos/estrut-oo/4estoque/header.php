<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Controle de Estoque Simplificado</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php if( basename($_SERVER['REQUEST_URI'], ".php")=='estoque'){ ?>
    <link href="./assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<?php }else{ ?> 
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<?php } ?>
    <style type="text/css">
    .panel-footer {
        padding: 0;
        background: none;
    }
    </style>
</head>
