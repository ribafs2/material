# Tipos de programação quanto a sincronicidade

## Programação síncrona

é quando uma instrução depende da finalização de outra instrução para ser executada

## Programação assíncrona

É quando uma instrução não depende da finalização de outra instrução para ser executada

Um código assíncrono é complicado de entender e difícil de ler

## Programação assíncrona

As operações custosas são enfileiradas e retomadas posteriormente quando estiverem disponíveis


