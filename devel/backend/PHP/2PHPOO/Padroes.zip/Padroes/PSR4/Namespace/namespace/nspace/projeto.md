# Namespace

Criar um aplicativo com estrutura MVC, dentro da pasta app
Aplicar o namespace com PSR-4 e composer
Explicando cada passo dado

Primeiro criarei a estrutura usando requires
Depois mudarei na segunda fase para namespace
Criação da estrutura MVC

app
    Controller
    Model
    View

Esta fase não usa namespace, somente requires.
