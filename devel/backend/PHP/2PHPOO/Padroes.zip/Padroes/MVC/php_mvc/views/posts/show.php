<p>This is the requested post:</p>

<p><?php echo $post->author; ?></p>
<p><?php echo $post->content; ?></p>