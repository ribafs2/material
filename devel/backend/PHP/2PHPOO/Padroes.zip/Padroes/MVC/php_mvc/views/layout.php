<DOCTYPE html>
<html>
  <head>
  </head>
  <body>
    <header>
      <a href='index.php'>Home</a>
      <a href='?controller=posts&action=index'>Posts</a>
    </header>

    <?php require_once('routes.php'); ?>

    <footer>
      Copyright
    </footer>
  <body>
<html>
