<div class="container">
    <h1>Início</h1>
    <h2>Você está na View: application/view/home/index.php</h2>
    <p>Em uma aplicação real esta pode ser a homepage inicial com conteúdo customizado ou então pode ser removida e tornar a inicial um dos outros.</p>
</div>
