<h1>User MVC Demo</h1>
<a href="?r=/list">Start</a>