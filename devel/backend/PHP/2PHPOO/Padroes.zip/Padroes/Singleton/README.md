# Conexão usando Singleton

Garante que somente uma conexão estará aberta de cada vez

Ao ser solicitada uma conexão será verificado se existe um objeto:
- Se existir será oferecido
- Se não existir será criada uma nova instância

Assim impede que sejam criados diversos objetos de conexão, otimizando o aplicativo.

Veja neste diretório 4 exemplos.


