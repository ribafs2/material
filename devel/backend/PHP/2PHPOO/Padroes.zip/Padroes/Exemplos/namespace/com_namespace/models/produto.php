<?php

namespace models;

class Produto{
    public function mostrarDetalhes(){
        echo 'Detalhes do produto da pasta models';
    }
}
