<?php

namespace DesignPatterns\More\ServiceLocator;

interface Service
{

}
