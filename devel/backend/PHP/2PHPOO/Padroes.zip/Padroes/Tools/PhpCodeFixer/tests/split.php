<?php

class Banana {
  public $split = 'tasty';
}

password_hash($password, PASSWORD_DEFAULT);
