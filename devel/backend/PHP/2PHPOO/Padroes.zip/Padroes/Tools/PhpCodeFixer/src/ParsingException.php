<?php
namespace wapmorgan\PhpCodeFixer;

class ParsingException extends \Exception
{
}
