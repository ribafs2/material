<?php
mcrypt_decrypt();

ini_set('session.hash_function', true);


mb_ereg_replace ("[^A-Za-z0-9\.\-]", "" , $data, "msre");

class iterable {}
