<?php
mcrypt_generic_end();
magic_quotes_runtime();
