<?php
dl('mysql');
ini_set('define_syslog_variables', false);
$hoho = 123;
piet(&$hoho);
