<?php
namespace wapmorgan\PhpCodeFixer;

use Exception;

class ConfigurationException extends Exception {}
