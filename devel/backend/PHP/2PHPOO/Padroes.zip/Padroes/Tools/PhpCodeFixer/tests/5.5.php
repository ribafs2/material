<?php
preg_replace('~'.preg_quote('asdasd').'asdasd'.$abc.'asdasdsd~ie', 'asdasd', $a);
