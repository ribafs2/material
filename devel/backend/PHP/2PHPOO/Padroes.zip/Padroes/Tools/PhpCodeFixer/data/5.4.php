<?php
return [
    'functions' => [
        'mcrypt_generic_end' => 'mcrypt_generic_deinit',
        'magic_quotes_runtime',
        'mysql_list_dbs',
    ]
];
