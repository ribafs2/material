<?php

require_once 'vendor/autoload.php';

use Cafe\Database;
use Cafe\Page;
use Cafe\Controller;

$teste = new Controller;
