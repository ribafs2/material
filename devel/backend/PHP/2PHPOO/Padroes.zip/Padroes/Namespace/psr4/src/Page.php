<?php

namespace Cafe;

class Page{
    public function __construct(){
        echo 'Olá Page';
    }
}
