# encadeando-metodos-php
Exemplo básico para utilização de métodos encadeados em php. Realizado com a finalidade de solidificar os conhecimentos de POO através da prática.
