# Beautiful PHP CLI Code Examples

Here are the examples I used in [my slides](http://www.slideshare.net/donatJ1/beautiful-phpcli-scripts) for my talk Beautiful PHP CLI Scripts.  

CLI Toolkit can be found [here](https://github.com/donatj/CLI-Toolkit).
