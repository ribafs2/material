#!/usr/bin/env php
<?php

print_r($argv);