<?php

echo php_sapi_name();