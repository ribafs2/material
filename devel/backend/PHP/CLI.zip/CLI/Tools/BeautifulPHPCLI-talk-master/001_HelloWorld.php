<?php

echo "Hello World!";
echo PHP_EOL;