# PHP-CLI

PHP para a linha de comando - CLI - Command Line Interface


