# Referências sobre PHP-CLI

- https://stevegrunwell.com/slides/php-cli

- https://github.com/hanneskod/comphlete - Dynamic bash completion from PHP

- https://github.com/donatj/cli-toolkit - PHP CLI Toolkit

- https://github.com/phpixie/console

- https://github.com/yidas/deployer-php-cli - CI/CD Deployment tool written in PHP supported for popular frameworks (Yii2, Laravel, CI3)

- https://github.com/Ghostff/pretty_data_dump

- Bash Reference Manual - https://www.gnu.org/savannah-checkouts/gnu/bash/manual/bash.html

- https://github.com/gabrielrcouto/php-terminal-gameboy-emulator


