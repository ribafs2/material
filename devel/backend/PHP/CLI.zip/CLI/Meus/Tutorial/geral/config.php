<?php

define('WID', system('tput cols')); // No linux resultado de: tput cols ou stty size, echo $COLUMNS


