<?php

require_once 'php-cli';
print Cli::charUTF8Hor('▚',20);
//Cli::menu('Menu Principal',['Backup banco MySQL']); // string $title, array $items, $fgColor = 'white', $bgColor = 'green'
//Cli::menuWin('Menu Principal',['Backup banco MySQL','segundo', 'tereceiro']); // string $title, array $menuItens, string $fgColor strinng $bgColor


