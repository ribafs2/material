#!/usr/bin/env php
<?php
// Prende o cursos
while( $line = fgets( STDIN ) ) {
  fwrite( STDOUT, $line );
}
