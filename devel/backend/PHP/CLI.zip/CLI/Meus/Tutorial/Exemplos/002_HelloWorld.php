#!/usr/bin/env php
<?php

fwrite( STDOUT, "Hello World!" );
fwrite( STDOUT, PHP_EOL );