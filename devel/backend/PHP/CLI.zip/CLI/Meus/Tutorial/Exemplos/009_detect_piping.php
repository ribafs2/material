<?php

echo intval( posix_isatty(STDOUT) );