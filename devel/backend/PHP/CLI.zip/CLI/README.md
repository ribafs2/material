# php-cli

PHP para a linha de comando - CLI - Command Line Interface

Com a popularização do Git e do Composer o uso do PHP na linha de comando se tornou muito frequente para programadores PHP.

Seguem boas dicas e exemplos para facilitar o entendimento.
