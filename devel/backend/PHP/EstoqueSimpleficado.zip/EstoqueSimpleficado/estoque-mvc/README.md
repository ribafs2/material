# Estoque simplificado usando o Micro Framework

Uma versão do estoque simplificado com MVC


