<?php
declare(strict_types = 1);

namespace App\Controllers;

use App\Models\Sale;
use Core\View;

class SaleController
{
    public function index()
    {
        $Sale = new Sale('sales');
        $fetchAll = $Sale->index();

        $view = new View();
        $view->render('sales/index', $fetchAll);
    }
    
    public function create()
    {
        $Sale = new Sale('sales');

        if (isset($_POST['submit_create_sale'])) {
            $Product->create($_POST['product_id'], $_POST['quantity'], $_POST['date'], $_POST['price']);
	        header('location: ' . URL . 'sate/index');	
        }

        $view = new View();
        $view->render('sales/create');
    }

    public function edit($field_id)
    {
        if (isset($field_id)) {
            $Sale = new Sale('sales');
            $regs = $Sale->edit($field_id);

            if ($regs === false) {
                $msg='Este registro não inexiste!';
                $error = new \Core\ErrorController();
                $error->index($msg);
            } else {
                $view = new View();
                $view->render('sales/edit', '', $regs);
            }
        } else {
            header('location: ' . URL . 'sale/index');
        }
    }
    // Observe que o render precisa do nome da tabela no plural e o location o nome da tabela no singular

    public function update()
    {
        if (isset($_POST['submit_update_sale'])) {
          $Sale = new Sale('sales');
          $Sale->update($_POST['product_id'], $_POST['quantity'], $_POST['date'], $_POST['price'], $_POST['field_id']);
        }
        header('location: ' . URL . 'sale/index');
    }

    public function delete($field_id)
    {
        if (isset($field_id)) {
            $Sale = new Sale('sales');
            $Sale->delete($field_id);
        }
        header('location: ' . URL . 'sale/index');
    }
}
