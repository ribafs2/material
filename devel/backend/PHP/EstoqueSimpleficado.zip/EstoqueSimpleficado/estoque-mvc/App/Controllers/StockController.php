<?php
declare(strict_types = 1);

namespace App\Controllers;

use App\Models\Stock;
use Core\View;

class StockController
{
    public function index()
    {
        $Stock = new Stock('stocks');
        $fetchAll = $Stock->index();

        $view = new View();
        $view->render('stocks/index', $fetchAll);
    }
    
    public function create()
    {
        $Stock = new Stock('stocks');

        if (isset($_POST['submit_create_stock'])) {
            $Product->create($_POST['product_id'], $_POST['quantity']);
	        header('location: ' . URL . 'stock/index');	
        }

        $view = new View();
        $view->render('stocks/create');
    }

    public function edit($field_id)
    {
        if (isset($field_id)) {
            $Stock = new Stock('stocks');
            $regs = $Stock->edit($field_id);

            if ($regs === false) {
                $msg='Este registro não inexiste!';
                $error = new \Core\ErrorController();
                $error->index($msg);
            } else {
                $view = new View();
                $view->render('stocks/edit', '', $regs);
            }
        } else {
            header('location: ' . URL . 'stock/index');
        }
    }
    // Observe que o render precisa do nome da tabela no plural e o location o nome da tabela no singular

    public function update()
    {
        if (isset($_POST['submit_update_stock'])) {
          $Stock = new Stock('stocks');
          $Stock->update($_POST['product_id'], $_POST['quantity'], $_POST['field_id']);
        }
        header('location: ' . URL . 'stock/index');
    }

    public function delete($field_id)
    {
        if (isset($field_id)) {
            $Product = new Product('stocks');
            $Product->delete($field_id);
        }
        header('location: ' . URL . 'stock/index');
    }
}
