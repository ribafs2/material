<?php
declare(strict_types = 1);

namespace App\Controllers;

use App\Models\Purchase;
use Core\View;

class PurchaseController
{
    public function index()
    {
        $Purchase = new Purchase('purchases');
        $fetchAll = $Purchase->index();

        $view = new View();
        $view->render('purchases/index', $fetchAll);
    }
    
    public function create()
    {
        $Purchase = new Purchase('purchases');

        if (isset($_POST['submit_create_purchase'])) {
            $Product->create($_POST['product_id'], $_POST['quantity'], $_POST['price'], $_POST['date']);
	        header('location: ' . URL . 'purchase/index');	
        }

        $view = new View();
        $view->render('purchases/create');
    }

    public function edit($field_id)
    {
        if (isset($field_id)) {
            $Purchase = new Purchase('puschases');
            $regs = $Purchase->edit($field_id);

            if ($regs === false) {
                $msg='Este registro não inexiste!';
                $error = new \Core\ErrorController();
                $error->index($msg);
            } else {
                $view = new View();
                $view->render('purchases/edit', '', $regs);
            }
        } else {
            header('location: ' . URL . 'purchase/index');
        }
    }
    // Observe que o render precisa do nome da tabela no plural e o location o nome da tabela no singular

    public function update()
    {
        if (isset($_POST['submit_update_purchase'])) {
          $Purchase = new Purchase('purchases');
          $Purchase->update($_POST['product_id'], $_POST['quantity'], $_POST['price'], $_POST['date'] $_POST['field_id']);
        }
        header('location: ' . URL . 'purchase/index');
    }

    public function delete($field_id)
    {
        if (isset($field_id)) {
            $Purchase = new Purchase('purchases');
            $Purchase->delete($field_id);
        }
        header('location: ' . URL . 'purchase/index');
    }
}
