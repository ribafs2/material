<div class="container">
    <h2 class="text-center">Sale</h2>
    <div>
		<br><br>
        <form action="<?php echo URL; ?>sale/update" method="POST">   
        <table class="table table-hover table-stripped">
            <tr><td><label>Product ID</label></td>
            <td><input class="form-control" type="text" name="product_id" value="<?php echo htmlspecialchars($regs->product_id, ENT_QUOTES, 'UTF-8'); ?>" required autofocus/></td></tr>
            <td><label>Quantity</label></td>
            <td><input class="form-control" type="text" name="quantity" value="<?php echo htmlspecialchars($regs->quantity, ENT_QUOTES, 'UTF-8'); ?>" required /></td></tr>
            <td><label>Price</label></td>
            <td><input class="form-control" type="text" name="price" value="<?php echo htmlspecialchars($regs->price, ENT_QUOTES, 'UTF-8'); ?>" required /></td></tr>
            <td><label>Date</label></td>
            <td><input class="form-control" type="date" name="date" value="<?php echo htmlspecialchars($regs->date, ENT_QUOTES, 'UTF-8'); ?>" required /></td></tr>
            <input type="hidden" name="field_id" value="<?php echo htmlspecialchars($regs->id, ENT_QUOTES, 'UTF-8'); ?>" />
            <tr><td></td><td><input type="submit" name="submit_update_sale" value="Update Sale" class="btn btn-primary btn-sm"/></td></tr>
		</table>
        </form>
    </div>
</div>

