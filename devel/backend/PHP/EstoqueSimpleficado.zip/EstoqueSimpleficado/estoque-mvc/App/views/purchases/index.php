<!-- Busca form -->
<br>
<div class="container">
	<a class="btn btn-primary btn-sm mt-3" href="<?=URL . 'purchase/create'; ?>">Add Purchase</a>
    <div>
        <br>        
        <table class="table table-hover table-stripped">
            <thead>
            <tr class="bg-gray">
                <td><strong>ID</strong></td>
                <td><strong>Product ID</strong></td>
                <td><strong>Quantity</strong></td>
                <td><strong>Price</strong></td>
                <td><strong>Date</strong></td>
                <td colspan="2"><strong>Actions</strong></td>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($fetchAll as $purchase) { ?>
                <tr>
                    <td><?php if (isset($purchase->id)) echo htmlspecialchars($purchase->id, ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php if (isset($purchase->product_id)) echo htmlspecialchars($purchase->product_id, ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php if (isset($purchase->quantity)) echo htmlspecialchars($purchase->quantity, ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php if (isset($purchase->price)) echo htmlspecialchars($purchase->price, ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php if (isset($purchase->date)) echo htmlspecialchars($purchase->date, ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><a href="<?=URL . 'purchase/edit/' . htmlspecialchars($purchase->id, ENT_QUOTES, 'UTF-8')?>">Edit</a></td>
                    <td><a onclick="return confirm('Really delete ?')" href="<?=URL . 'purchase/delete/' . htmlspecialchars($purchase->id, ENT_QUOTES, 'UTF-8')?>">Delete</a></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</div>
