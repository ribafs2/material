<div class="container bg-gray">
    <div align="center">
        <a href="<?=URL . 'customer/index'?>" class="text-center">Voltar ao menu</a><br>
        <a href="https://github.com/ribafs/micro-framework">Micro Framework no GitHub</a>.<br>
    </div>
</div>
</body>
</html>

