<div class="container text-danger">
    <h3 class="text-center" style="padding: 100px; margin-bottom: 150px">
    <?=$msg?></h3>
</div>

