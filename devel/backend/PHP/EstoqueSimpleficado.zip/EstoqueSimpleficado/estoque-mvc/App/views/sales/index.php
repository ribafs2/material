<!-- Busca form -->
<br>
<div class="container">
	<a class="btn btn-primary btn-sm mt-3" href="<?=URL . 'sale/create'; ?>">Add Sale</a>
    <div>
        <br>        
        <table class="table table-hover table-stripped">
            <thead>
            <tr class="bg-gray">
                <td><strong>ID</strong></td>
                <td><strong>Product ID</strong></td>
                <td><strong>Quantity</strong></td>
                <td><strong>Price</strong></td>
                <td><strong>Date</strong></td>
                <td colspan="2"><strong>Actions</strong></td>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($fetchAll as $sale) { ?>
                <tr>
                    <td><?php if (isset($sale->id)) echo htmlspecialchars($sale->id, ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php if (isset($sale->product_id)) echo htmlspecialchars($sale->product_id, ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php if (isset($sale->quantity)) echo htmlspecialchars($sale->quantity, ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php if (isset($sale->price)) echo htmlspecialchars($sale->price, ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php if (isset($sale->date)) echo htmlspecialchars($sale->date, ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><a href="<?=URL . 'sale/edit/' . htmlspecialchars($sale->id, ENT_QUOTES, 'UTF-8')?>">Edit</a></td>
                    <td><a onclick="return confirm('Really delete ?')" href="<?=URL . 'sale/delete/' . htmlspecialchars($sale->id, ENT_QUOTES, 'UTF-8')?>">Delete</a></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</div>
