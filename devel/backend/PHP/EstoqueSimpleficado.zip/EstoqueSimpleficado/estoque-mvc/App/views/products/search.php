<?php
    if(isset($_GET['keyword'])){
        print '<div class="container" align="center">';

        if(count($regs) > 0){
    ?>
		<h3>Register(s) found: <?=count($regs)?></h3> 
        <div class="container" align="center">
            <table class="table table-striped table-sm table-bordered table-hover"> 
            <tr>
              <th>ID</th><th>Description</th><th>Minimum Stock</th><th>Maximum Stock</th>
            </tr>
     
        <?php
            foreach ($regs as $row){
              print '<tr>';
              print '<td>'.$row->id.'</td><td>'.$row->description.'</td><td>'.$row->minimum_stock.'</td><td>'.$row->minimum_stock.'</td>';
              print '</tr>';
            } 
            echo "</table>";
        }else{
            print '<h3>Register not found!</h3>';
        }
    }
    require_once APP . 'views/templates/footer.php';        
    exit;
?>
