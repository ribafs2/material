<div class="container">
    <h2 class="text-center">Purchase</h2>
    <div>
        <br>
        <form action="<?php echo URL; ?>purchase/create" method="POST">   
        <table class="table table-hover table-stripped">
            <tr><td><label>Product ID</label></td>
            <td><input class="form-control" type="text" name="product_id" required /></td></tr>
            <td><label>Quantity</label></td>
            <td><input class="form-control" type="text" name="quantity" required /></td></tr>
            <td><label>Price</label></td>
            <td><input class="form-control" type="text" name="price" required /></td></tr>
            <td><label>Date</label></td>
            <td><input class="form-control" type="date" name="date" required /></td></tr>
            <tr><td></td><td><input type="submit" name="submit_create_purchase" value="Purchase Product" class="btn btn-primary btn-sm"/></td></tr>
		</table>
        </form>
    </div>
</div>
