<div class="container">
    <h2 class="text-center">Product</h2>
    <div>
		<br><br>
        <form action="<?php echo URL; ?>product/update" method="POST">   
        <table class="table table-hover table-stripped">
            <tr><td><label>Description</label></td>
            <td><input class="form-control" type="text" name="description" value="<?php echo htmlspecialchars($regs->description, ENT_QUOTES, 'UTF-8'); ?>" required autofocus/></td></tr>
            <td><label>Minimum Stock</label></td>
            <td><input class="form-control" type="text" name="minimum_stock" value="<?php echo htmlspecialchars($regs->minimum_stock, ENT_QUOTES, 'UTF-8'); ?>" required /></td></tr>
            <td><label>Maximum Stock</label></td>
            <td><input class="form-control" type="text" name="maximum_stock" value="<?php echo htmlspecialchars($regs->maximum_stock, ENT_QUOTES, 'UTF-8'); ?>" required /></td></tr>
            <input type="hidden" name="field_id" value="<?php echo htmlspecialchars($regs->id, ENT_QUOTES, 'UTF-8'); ?>" />
            <tr><td></td><td><input type="submit" name="submit_update_product" value="Update Product" class="btn btn-primary btn-sm"/></td></tr>
		</table>
        </form>
    </div>
</div>

