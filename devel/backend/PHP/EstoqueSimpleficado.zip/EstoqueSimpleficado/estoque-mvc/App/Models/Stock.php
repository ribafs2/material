<?php
declare(strict_types = 1);

namespace App\Models;

use Core\Connection;

class Stock
{ 
    public $table;

    public function __construct($table)
    {
        $this->table = $table;

        // Iniciando a classe de conexão com Singleton
        try {
        	$pdo = Connection::getInstance();
            $this->pdo = $pdo;
        	Connection::setCharsetEncoding();          
        } catch (Exception $e) {
	        print $e->getMessage();          
        }
    }

    public function index()
    {
	    $sql = "SELECT * FROM {$this->table} ORDER BY id DESC";
	    $query = $this->pdo->prepare($sql);
	    $query->execute();
        return $query->fetchAll();
    }

    public function create($product_id, $quantity)
    {
        $sql = "INSERT INTO {$this->table} (product_id, quantity) VALUES (:product_id, :quantity)";
        $query = $this->pdo->prepare($sql);
        $parameters = array(":product_id" => $product_id, ":quantity" => $quantity);
        $query->execute($parameters);
    }

    public function edit($field_id)
    {
        $sql = "SELECT id, product_id, quantity FROM {$this->table} WHERE id = :field_id LIMIT 1";
        $query = $this->pdo->prepare($sql);
        $parameters = array(':field_id' => $field_id);
        $query->execute($parameters);
        return ($query->rowCount() ? $query->fetch() : false);
    }

    public function update($product_id, $quantity, $field_id)
    {
        $sql = "UPDATE {$this->table} SET product_id = :product_id, quantity = :quantity WHERE id = :field_id";
        $query = $this->pdo->prepare($sql);
        $parameters = array(':product_id' => $product_id, ':quantity' => $quantity ':field_id' => $field_id);
        $query->execute($parameters);
    }

    public function delete($field_id)
    {
        $sql = "DELETE FROM {$this->table} WHERE id = :field_id";
        $query = $this->pdo->prepare($sql);
        $parameters = array(':field_id' => $field_id);
        $query->execute($parameters);
    }    
}
