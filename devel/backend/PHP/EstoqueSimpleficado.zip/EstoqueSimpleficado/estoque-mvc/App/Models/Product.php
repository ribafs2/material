<?php
declare(strict_types = 1);

namespace App\Models;

use Core\Connection;

class Product
{ 
    public $table;

    public function __construct($table)
    {
        $this->table = $table;

        // Iniciando a classe de conexão com Singleton
        try {
        	$pdo = Connection::getInstance();
            $this->pdo = $pdo;
        	Connection::setCharsetEncoding();          
        } catch (Exception $e) {
	        print $e->getMessage();          
        }
    }

    public function index()
    {
	    $sql = "SELECT * FROM {$this->table} ORDER BY id DESC";
	    $query = $this->pdo->prepare($sql);
	    $query->execute();
        return $query->fetchAll();
    }

    public function create($name, $price)
    {
        $sql = "INSERT INTO {$this->table} (description, maximum_stock, minimum_stock) VALUES (:descriptiom, :maximum_stock, :minimum_stock)";
        $query = $this->pdo->prepare($sql);
        $parameters = array(":descriptiom" => $descriptiom, ":maximum_stock" => $maximum_stock, ":minimum_stock" => $minimum_stock);
        $query->execute($parameters);
    }

    public function edit($field_id)
    {
        $sql = "SELECT id, description, maximum_stock, minimum_stock FROM {$this->table} WHERE id = :field_id LIMIT 1";
        $query = $this->pdo->prepare($sql);
        $parameters = array(':field_id' => $field_id);
        $query->execute($parameters);
        return ($query->rowCount() ? $query->fetch() : false);
    }

    public function update($description, $maximum_stock, $minimum_stock, $field_id)
    {
        $sql = "UPDATE {$this->table} SET description = :description, maximum_stock = :maximum_stock, minimum_stock = :minimum_stock WHERE id = :field_id";
        $query = $this->pdo->prepare($sql);
        $parameters = array(':description' => $description, ':maximum_stock' => $maximum_stock, ':minimum_stock' => $minimum_stock, ':field_id' => $field_id);
        $query->execute($parameters);
    }

    public function delete($field_id)
    {
        $sql = "DELETE FROM {$this->table} WHERE id = :field_id";
        $query = $this->pdo->prepare($sql);
        $parameters = array(':field_id' => $field_id);
        $query->execute($parameters);
    }    

    public function search($keyword)
    {
        $sql = "select * from {$this->table} WHERE description LIKE :keyword order by id";
        $sth = $this->pdo->prepare($sql);
        $sth->bindValue(":keyword", "%".$keyword."%");
        $sth->execute();
        $rows =$sth->fetchAll();
        return $rows;
    }   
}
