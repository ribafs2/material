<?php
declare(strict_types = 1);

namespace App\Models;

use Core\Connection;

class Purchase
{ 
    public $table;

    public function __construct($table)
    {
        $this->table = $table;

        // Iniciando a classe de conexão com Singleton
        try {
        	$pdo = Connection::getInstance();
            $this->pdo = $pdo;
        	Connection::setCharsetEncoding();          
        } catch (Exception $e) {
	        print $e->getMessage();          
        }
    }

    public function index()
    {
	    $sql = "SELECT * FROM {$this->table} ORDER BY id DESC";
	    $query = $this->pdo->prepare($sql);
	    $query->execute();
        return $query->fetchAll();
    }

    public function create($product_id, $quantity, $price, $date)
    {
        $sql = "INSERT INTO {$this->table} (product_id, quantity, pricec, date) VALUES (:product_id, :quantity, :price, :date)";
        $query = $this->pdo->prepare($sql);
        $parameters = array(":product_id" => $product_id, ":quantity" => $quantity, ":price" => $price, ":date" => $date);
        $query->execute($parameters);
    }

    public function edit($field_id)
    {
        $sql = "SELECT id, product_id, quantity, price, date FROM {$this->table} WHERE id = :field_id LIMIT 1";
        $query = $this->pdo->prepare($sql);
        $parameters = array(':field_id' => $field_id);
        $query->execute($parameters);
        return ($query->rowCount() ? $query->fetch() : false);
    }

    public function update($product_id, $quantity, $price, $date, $field_id)
    {
        $sql = "UPDATE {$this->table} SET product_id = :product_id, quantity = :quantity, price = :price, date = :date WHERE id = :field_id";
        $query = $this->pdo->prepare($sql);
        $parameters = array(':product_id' => $product_id, ':quantity' => $quantity, ':price' => $price, ':date' => $date ':field_id' => $field_id);
        $query->execute($parameters);
    }

    public function delete($field_id)
    {
        $sql = "DELETE FROM {$this->table} WHERE id = :field_id";
        $query = $this->pdo->prepare($sql);
        $parameters = array(':field_id' => $field_id);
        $query->execute($parameters);
    }    
}
