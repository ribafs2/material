CREATE TABLE products (
    id INT NOT NULL AUTO_INCREMENT,
    description VARCHAR(50) UNIQUE NOT NULL,
    minimum_stock INT NOT NULL,
    maximum_stock INT NOT NULL,
    PRIMARY KEY (id)
);

insert into products (description, minimum_stock,maximum_stock) values 
('Banana', 10, 100);

CREATE TABLE purchases (
    id INT NOT NULL AUTO_INCREMENT,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(9,2) NOT NULL,
    date DATE NULL DEFAULT NULL,
    PRIMARY KEY (id),
	constraint purchase_fk foreign key (product_id) references products(id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE stocks (
    id INT NOT NULL AUTO_INCREMENT,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    PRIMARY KEY (id),
	constraint stock_fk foreign key (product_id) references products(id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE sales (
    id INT NOT NULL AUTO_INCREMENT,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    date DATE NULL DEFAULT NULL,
    price DECIMAL(9,2) NOT NULL,
    PRIMARY KEY (id),
	constraint sale_fk foreign key (product_id) references products(id) ON DELETE CASCADE ON UPDATE CASCADE
);

