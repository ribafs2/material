<?php

define('APP_TITTLE', 'Estoque Simplificado em PHP com MVC');
define('DEFAULT_CONTROLLER', 'product');
define('DEBUG', true);

define('DB_TYPE', 'mysql'); // mysql or pgsql
define('DB_HOST', 'localhost');
define('DB_NAME', 'stock');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_PORT', '3306');// 3306 or 5432
define('DB_CHARSET', 'utf8mb4');


