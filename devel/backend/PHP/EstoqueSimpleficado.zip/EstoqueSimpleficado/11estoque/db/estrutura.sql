CREATE TABLE clientes (
    id int primary key auto_increment,
    nome varchar(50) not null,
    email varchar(50),
    cpf varchar(11)
);

CREATE TABLE funcionarios (
    id int primary key auto_increment,
    nome varchar(50) not null,
    email varchar(50),
    cpf varchar(11)
);

CREATE TABLE unidades (
    id int primary key auto_increment,
    unidade varchar(4) not null
);

CREATE TABLE compras (
    id int primary key auto_increment,
    data datetime not null
);

CREATE TABLE produtos (
    id int primary key auto_increment,
    nome varchar(50) not null,
    data_cadastro date,
    quantidade int,
    unidade_id int not null
);

CREATE TABLE compra_itens (
    id int primary key auto_increment,
    quantidade int not null,
    preco_unitario numeric(12,2),
    compra_id int not null,
    produto_id int not null,
	constraint compra_fk foreign key (compra_id) references compras(id),  
	constraint produto_fk foreign key (produto_id) references produtos(id)
);

CREATE TABLE estoques (
    id int primary key auto_increment,
    quantidade int not null,
    estoque_min int not null,
    data datetime,
    compra_id int not null,
	constraint estoque_compra_fk foreign key (compra_id) references compras(id)
);

CREATE TABLE pedidos (
    id int primary key auto_increment,
    data date not null,
    data_confirmacao date not null,
    cliente_id int not null,
    funcionario_id int not null,
    CONSTRAINT `fk-cliente` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk-funcionario` FOREIGN KEY (`funcionario_id`) REFERENCES `funcionarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE pedido_itens (
    id int primary key auto_increment,
    quantidade int not null,
    preco_venda numeric(12,2) not null,
    estoque_id int not null,
    pedido_id int not null,
    CONSTRAINT `fk-estoque` FOREIGN KEY (`estoque_id`) REFERENCES `estoques` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk-pedido` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
);

