<?php

require_once 'header_idx.php'

?>
<table class="table">
<tr><td><a href="clientes">Clientes</a></td><td><a href="compra_itens">Itens de comprar</a></td><td><a href="compras">Compras</a></td><td><a href="estoques">Estoques</a></td><td><a href="funcionarios">Funcionários</a></td></tr>
<tr><td><a href="pedido_itens">Itens de pedidos</a></td><td><a href="pedidos">Pedidos</a></td><td><a href="produtos">Produtos</a></td><td><a href="unidades">Unidades</a></td></tr>
</table>

