<?php require_once 'header_idx.php'; ?>

        <table class="table">
            <tr>
                <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><h3><a href="produtos">Produtos</a></td>
                <td><h3><a href="compras">Compras</a></td>
                <td><h3><a href="vendas">Vendas</a></td>
                <td><h3><a href="estoques">Estoques</a></td>
            </tr>
        </table>
        <div class="text-center rounded mx-auto d-block">
            <img src="assets/estoque.jpg">
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
