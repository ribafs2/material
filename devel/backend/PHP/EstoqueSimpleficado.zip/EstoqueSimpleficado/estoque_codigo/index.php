<?php require_once 'header_idx.php'; ?>

        <table class="table">
            <tr>
                <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><a href="produtos">Produtos</a></td>
                <td><a href="compras">Compras</a></td>
                <td><a href="vendas">Vendas</a></td>
                <td><a href="estoques">Estoques</a></td>
            </tr>
        </table>
    </div>
</div>

<?php require_once 'footer.php'; ?>
