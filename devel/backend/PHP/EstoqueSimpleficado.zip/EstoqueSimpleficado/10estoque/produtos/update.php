<?php require_once('../header.php'); ?>
<style>

</style>
<div class="container">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <form method="post" action="">
                <table class="table table-bordered table-responsive table-hover">

<?php
require_once('../connect.php');

$id=$_GET['id'];

$sth = $pdo->prepare("SELECT id, nome,quantidade,data_cadastro,unidade_id from produtos WHERE id = :id");
$sth->bindValue(':id', $id, PDO::PARAM_STR); // No select e no delete basta um bindValue
$sth->execute();

$reg = $sth->fetch(PDO::FETCH_OBJ);

$id = $reg->id;
$nome = $reg->nome;
$data_cadastro = $reg->data_cadastro;
$quantidade = $reg->quantidade;
$unidade_id = $reg->unidade_id;
?>
   <h3>Produtos</h3>
   <tr><td>Nome</td><td><input name="nome" type="text" value="<?=$nome?>"></td></tr>
   <tr><td>Data de cadastro</td><td><input name="data_cadastro" type="text" value="<?=$data_cadastro?>"></td></tr>
   <tr><td>Quantidade</td><td><input name="quantidade" type="text" value="<?=$quantidade?>"></td></tr>
   <tr><td>ID Unidade</td><td><input name="unidade_id" type="text" value="<?=$unidade_id?>"></td></tr>
   <tr><td></td><td><input name="enviar" class="btn btn-primary" type="submit" value="Editar">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <input name="id" type="hidden" value="<?=$id?>">
   <input name="enviar" class="btn btn-warning" type="button" onclick="location='index.php'" value="Voltar"></td></tr>
       </table>
        </form>
        </div>
    <div>
</div>
<?php

if(isset($_POST['enviar'])){
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $data_cadastro = $_POST['data_cadastro'];
    $quantidade = $_POST['quantidade'];
    $unidade = $_POST['unidade_id'];

    $data = [
        'nome' => $nome,
        'data_cadastro' => $data_cadastro,
        'quantidade' => $quantidade,
        'unidade_id' => $unidade_id,
        'id' => $id,
    ];

    $sql = "UPDATE produtos SET nome=:nome, data_cadastro=:data_cadastro, quantidade=:quantidade, unidade_id=:unidade_id WHERE id=:id";
    $stmt= $pdo->prepare($sql);

   if($stmt->execute($data)){
        print "<script>alert('Registro alterado com sucesso!');location='index.php';</script>";
    }else{
        print "Erro ao editar o registro!<br><br>";
    }
}
require_once('../footer.php');
?>

