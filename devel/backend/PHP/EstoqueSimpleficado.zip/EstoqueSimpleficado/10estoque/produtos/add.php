<?php require_once '../header.php'; ?>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
        <h3>Produtos</h3>
        <table class="table table-bordered table-responsive">    
            <form method="post" action="add.php"> 
            <tr><td><b>Nome</td><td><input type="text" name="nome"></td></tr>
            <tr><td><b>Data de cadastro</td><td><input type="text" name="data_cadastro"></td></tr>
            <tr><td><b>Quantidade</td><td><input type="text" name="quantidade"></td></tr>
            <tr><td><b>ID Unidade</td><td><input type="text" name="unidade_id"></td></tr>
            <tr><td></td><td><input class="btn btn-primary" name="enviar" type="submit" value="Cadastrar">&nbsp;&nbsp;&nbsp;
            <input class="btn btn-warning" name="enviar" type="button" onclick="location='index.php'" value="Voltar"></td></tr>
            </form>
        </table>
        </div>
    </div>
</div>

<?php

if(isset($_POST['enviar'])){
    $nome = $_POST['nome'];
    $data_cadastro = $_POST['data_cadastro'];
    $quantidade = $_POST['quantidade'];
    $unidade_id = $_POST['unidade_id'];

    require_once('../connect.php');
    try{
       $sql = "INSERT INTO produtos(nome,data_cadastro,quantidade,unidade_id) VALUES (?, ?, ?, ?)";
       $stm = $pdo->prepare($sql)->execute([$nome, $data_cadastro, $quantidade, $unidade_id]);;
 
       if($stm){
           echo 'Dados inseridos com sucesso';
		   header('location: index.php');
       }
       else{
           echo 'Erro ao inserir os dados';
       }
   }
   catch(PDOException $e){
      echo $e->getMessage();
   }
}
require_once('../footer.php');
?>

