<?php require_once '../header.php'; ?>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
        <h3>Pedidos</h3>
        <table class="table table-bordered table-responsive">    
            <form method="post" action="add.php"> 
            <tr><td><b>Data</td><td><input type="text" name="data"></td></tr>
            <tr><td><b>Data de confirmação</td><td><input type="text" name="data_confirmacao"></td></tr>
            <tr><td><b>ID Cliente</td><td><input type="text" name="cliente_id"></td></tr>
            <tr><td><b>ID Funcionário</td><td><input type="text" name="funcionario_id"></td></tr>
            <tr><td></td><td><input class="btn btn-primary" name="enviar" type="submit" value="Cadastrar">&nbsp;&nbsp;&nbsp;
            <input class="btn btn-warning" name="enviar" type="button" onclick="location='index.php'" value="Voltar"></td></tr>
            </form>
        </table>
        </div>
    </div>
</div>

<?php

if(isset($_POST['enviar'])){
    $data = $_POST['data'];
    $data_confirmacao = $_POST['data_confirmacao'];
    $cliente_id = $_POST['cliente_id'];
    $funcionario_id = $_POST['funcionario_id'];

    require_once('../connect.php');
    try{
       $sql = "INSERT INTO pedidos(data,data_confirmacao,cliente_id,funcionario_id) VALUES (?, ?, ?, ?)";
       $stm = $pdo->prepare($sql)->execute([$data, $data_confirmacao, $cliente_id, $funcionario_id]);;
 
       if($stm){
           echo 'Dados inseridos com sucesso';
		   header('location: index.php');
       }
       else{
           echo 'Erro ao inserir os dados';
       }
   }
   catch(PDOException $e){
      echo $e->getMessage();
   }
}
require_once('../footer.php');
?>

