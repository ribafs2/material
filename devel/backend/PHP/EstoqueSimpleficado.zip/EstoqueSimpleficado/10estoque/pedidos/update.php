<?php require_once('../header.php'); ?>
<style>

</style>
<div class="container">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <form method="post" action="">
                <table class="table table-bordered table-responsive table-hover">

<?php
require_once('../connect.php');

$id=$_GET['id'];

$sth = $pdo->prepare("SELECT id, data,data_confirmacao,cliente_id,funcionario_id from pedidos WHERE id = :id");
$sth->bindValue(':id', $id, PDO::PARAM_STR); // No select e no delete basta um bindValue
$sth->execute();

$reg = $sth->fetch(PDO::FETCH_OBJ);

$id = $reg->id;
$data = $reg->data;
$data_confirmacao = $reg->data_confirmacao;
$cliente_id = $reg->cliente_id;
$funcionario_id = $reg->funcionario_id;
?>
   <h3>Pedidos</h3>
   <tr><td>Data</td><td><input name="data" type="text" value="<?=$data?>"></td></tr>
   <tr><td>Data de confirmacao</td><td><input name="data_confirmacao" type="text" value="<?=$data_confirmacao?>"></td></tr>
   <tr><td>ID Cliente</td><td><input name="cliente_id" type="text" value="<?=$cliente_id?>"></td></tr>
   <tr><td>ID Funcionário</td><td><input name="funcionario_id" type="text" value="<?=$funcionario_id?>"></td></tr>
   <tr><td></td><td><input name="enviar" class="btn btn-primary" type="submit" value="Editar">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <input name="id" type="hidden" value="<?=$id?>">
   <input name="enviar" class="btn btn-warning" type="button" onclick="location='index.php'" value="Voltar"></td></tr>
       </table>
        </form>
        </div>
    <div>
</div>
<?php

if(isset($_POST['enviar'])){
    $id = $_POST['id'];
    $data = $_POST['data'];
    $data_confirmacao = $_POST['data_confirmacao'];
    $cliente_id = $_POST['cliente_id'];
    $funcionario_id = $_POST['funcionario_id'];

    $data = [
        'data' => $data,
        'data_confirmacao' => $data_confirmacao,
        'cliente_id' => $cliente_id,
        'funcionario_id' => $funcionario_id,
        'id' => $id,
    ];

    $sql = "UPDATE pedidos SET data=:data, data_confirmacao=:data_confirmacao, cliente_id=:cliente_id, funcionario_id=:funcionario_id WHERE id=:id";
    $stmt= $pdo->prepare($sql);

   if($stmt->execute($data)){
        print "<script>alert('Registro alterado com sucesso!');location='index.php';</script>";
    }else{
        print "Erro ao editar o registro!<br><br>";
    }
}
require_once('../footer.php');
?>

