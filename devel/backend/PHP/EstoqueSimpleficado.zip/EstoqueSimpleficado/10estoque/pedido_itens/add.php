<?php require_once '../header.php'; ?>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
        <h3>Itens de pedidos</h3>
        <table class="table table-bordered table-responsive">    
            <form method="post" action="add.php"> 
            <tr><td><b>Quantidade</td><td><input type="text" name="quantidade"></td></tr>
            <tr><td><b>Preço de venda</td><td><input type="text" name="preco_venda"></td></tr>
            <tr><td><b>ID Estoque</td><td><input type="text" name="estoque_id"></td></tr>
            <tr><td><b>ID Pedido</td><td><input type="text" name="pedido_id"></td></tr>
            <tr><td></td><td><input class="btn btn-primary" name="enviar" type="submit" value="Cadastrar">&nbsp;&nbsp;&nbsp;
            <input class="btn btn-warning" name="enviar" type="button" onclick="location='index.php'" value="Voltar"></td></tr>
            </form>
        </table>
        </div>
    </div>
</div>

<?php

if(isset($_POST['enviar'])){
    $quantidade = $_POST['quantidade'];
    $preco_venda = $_POST['preco_venda'];
    $estoque_id = $_POST['estoque_id'];
    $pedido_id = $_POST['pedido_id'];

    require_once('../connect.php');
    try{
       $sql = "INSERT INTO pedido_itens(quantidade,preco_venda,estoque_id,pedido_id) VALUES (?, ?, ?, ?)";
       $stm = $pdo->prepare($sql)->execute([$quantidade, $preco_venda, $estoque_id, $pedido_id]);;
 
       if($stm){
           echo 'Dados inseridos com sucesso';
		   header('location: index.php');
       }
       else{
           echo 'Erro ao inserir os dados';
       }
   }
   catch(PDOException $e){
      echo $e->getMessage();
   }
}
require_once('../footer.php');
?>

