
<style>
footer {
    text-align:center;
    left: 0px;
    position:fixed;
    bottom:0px;
    width:100%;
}
</style>

<footer>
    <i>Adaptação de <a href="https://ribamar.net.br" target="_blank">Ribamar FS</a></i>
</footer>

</body>
</html>
