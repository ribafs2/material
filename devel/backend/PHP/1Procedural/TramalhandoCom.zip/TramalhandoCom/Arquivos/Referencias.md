A maneira certa de ler arquivos com PHP
https://developer.ibm.com/br/languages/php/articles/os-php-readfiles/
