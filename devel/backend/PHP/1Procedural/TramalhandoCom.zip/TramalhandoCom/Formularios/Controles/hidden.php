<?php
echo "Campo Hidden: " . $_POST["escondido"];
echo "<br>Oi, seu ID �: " . $_POST["id"];
?>