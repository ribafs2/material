<?php

 /*** create an array ***/
 $animals = array( 'dingo', 'wombat', 'Steve Irwin', 'playpus', 'emu' );

 /*** loop over the array ***/
 foreach( $animals as $animal )
 {
        echo $animal.'<br />';
 }
