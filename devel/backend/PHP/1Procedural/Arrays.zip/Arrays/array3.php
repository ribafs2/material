<?php

  /*** create an array ***/
  $animals = array(
        0=>'dingo',
        1=>'wombat',
        2=>'Steve Irwin',
        3=>'playpus',
        4=>'emu',
        'goanna',
        21=>'wallaby',
        );

 /*** dump the array contents ***/
print '<pre>';
 print_r( $animals );

?> 
