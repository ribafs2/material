<?php
 /*** create an empty array ***/
 $array = array();

 /*** check if $array is and array ***/
 if(is_array($array))
 {
        /*** if it is an array ***/
        echo 'Variable is an array';
 }
 else
 {
        /*** if it is not an array ***/
        echo 'Variable is not an array';
 }

?> 
