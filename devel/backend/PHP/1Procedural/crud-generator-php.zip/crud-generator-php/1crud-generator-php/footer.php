<div class="container footer text-center">
    <i>"Adapted by <a href="https://ribafs.org" target="_blank">Ribamar FS</a></i>
</div>
<br>
</body>
</html>
