<?php

function countWords($str){    
  return str_word_count($str);
}  
// Printing the result
echo countWords('  Geeks for Geeks  for Riba'); 
//https://stackoverflow.com/questions/18679576/counting-words-in-string

