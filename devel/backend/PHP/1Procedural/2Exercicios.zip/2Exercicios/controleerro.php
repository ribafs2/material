<?php
/* Erro intencional */

$a = 6;
$b = 0;

echo "Camuflando erro de divis�o por zero";
$c = @($a / $b);

?>
