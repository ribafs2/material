## Sintaxe alternativa
```php
while ($i < 10): echo $i++; endwhile;
for ($i = 0; $i < 10; $i++): echo $i; endfor;
foreach ($a as $v): echo $v; endforeach;
```
