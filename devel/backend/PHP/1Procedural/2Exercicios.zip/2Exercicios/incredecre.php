<?php
echo "<h3>P�s-incremento</h3>";
$a = 5;
echo "\$a = ".$a."<br><br>";
echo "\$a++ deve ser: " . $a++ . "<br />\n";
echo "\$a deve ser: " . $a . "<br />\n";

echo "<h3>Pr�-incremento</h3>";
$a = 5;
echo "++\$a deve ser: " . ++$a . "<br />\n";
echo "\$a deve ser: " . $a . "<br />\n";

echo "<h3>P�s-decremento</h3>";
$a = 5;
echo "\$a-- deve ser: " . $a-- . "<br />\n";
echo "\$a deve ser: " . $a . "<br />\n";

echo "<h3>Pr�-decremento</h3>";
$a = 5;
echo "--\$a deve ser: " . --$a . "<br />\n";
echo "\$a deve ser: " . $a . "<br />\n";
?> 
