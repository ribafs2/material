<?php

$a = "Ol� ";
$b = $a . "mundo do PHP!";

echo $b;

$a = "Ol� ";
$a .= "meu mundo!";

echo "<br>" . $a;

?>
