<?php

$a = 1; $b = 5;

if ($a > $b) {
   echo "\$a � maior que \$b";
} elseif ($a == $b) {
   echo "\$a � igual a \$b";
} else {
   echo "\$a � menor que \$b";
}
?> 
