<?php
$a = 3;
$b = 5;
if ($a > $b){
   echo "a � maior que b";
} else {
   echo "a N�O � maior que b";
}
?>
