<?php

$a = 3; $b = 1;

if ($a < $b) {
   echo "\$a � menor que \$b";
} else {
   echo "\$a � maior que \$b";
}

/* Sintaxe alternativa (em obsolenc�ncia)

if ($a == 5):
	echo "A � igual a 5";
endif;

Esta sintaxe pode ser utilizada com todas as estruturas de controle, mas n�o deve.
*/

?> 
