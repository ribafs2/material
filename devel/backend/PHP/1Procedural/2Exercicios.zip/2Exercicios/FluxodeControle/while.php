<?php
/* exemplo 1 */

$i = 1;
while ($i <= 10) {
   echo $i++;  /* o valor impresso ser�
                   $i depois do acr�scimo
                   (post-increment) */
}

/* exemplo 2 

$i = 1;
while ($i <= 10):
   echo $i;
   $i++;
endwhile;
*/
?> 
