<?php
echo "Olá Mundo do PHP!";
?>
