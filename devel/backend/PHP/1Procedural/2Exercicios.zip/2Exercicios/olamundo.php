<?php
class OlaMundo{
	function OlaMundo(){
		return "Ol� Mundo do PHPOO!";
	}
}

$ola = new OlaMundo();
echo $ola->OlaMundo();
?>
