<?php
$a = 1.234;
echo $a."<br>";
$b = 1.2e3;
echo $b."<br>";
$c = 7E-4;
echo $c;
?>
