<?php

/*** test for a boolean value ***/
echo filter_var("true", FILTER_VALIDATE_BOOLEAN);

// Retorna 1, pois true é boolean
?>
