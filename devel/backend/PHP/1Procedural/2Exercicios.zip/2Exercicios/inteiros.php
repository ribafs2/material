<?php
$a =1234;
echo $a."<br>"; // número decimal
$a =-123;
echo $a."<br>"; // um número negativo
$a =0123;
echo $a."<br>"; // número octal (equivalente a 83 em decimal)
$a =0x1A;
echo $a."<br>"; // número hexadecimal (equivalente a 26 em decimal)
?> 
