# CRUD com PHP PDO e BootStrap

Com suporte ao SQLite, ao MySQL e ao PostgreSQL

Basta que crie o banco no MySQL ou no PostgreSQL (o do sqlite já está criado em db/sqlite3.db), importe o respectivo script da apsta db e altere as informações em connection.

Então chame o index em seu diretório web.

## Original

https://www.sourcecodester.com/download-code?nid=12699&title=PHP+-+Simple+CRUD+With+SQLite+Using+PDO


