<footer class="text-center">
    <i>Adaptação de <a href="https://ribamar.net.br" target="_blank">Ribamar FS</a></i>
</footer>

</body>
</html>
