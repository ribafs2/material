# CRUD em PHP com bons recursos

- Bootstrap 4
- Paginação
- Busca

