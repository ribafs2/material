<hr>
<div class="container">
<div class="footer">
	<div class="alert alert-info">
        Criado por <a href="https://ribafs.org">Ribamar FS</a>!
	</div>
</div>
</div>
</body>
</html>
