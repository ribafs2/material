<?php

// Variáveis
$title = 'CRUD com Paginação, PDO, BootStrap e Busca';
$max_visible = 15;
