# CRUD com bons recursos

- PDO
- Paginação
- Botstrap
- Busca
- header.php e footer.php
- Alguns parâmetros mo connect.php
- Suporte ao PostgreSQL

Esta versão usa PHP estruturado

