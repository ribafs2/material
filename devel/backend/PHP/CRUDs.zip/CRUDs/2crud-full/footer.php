<div class="container footer text-center">
    <i>"Adaptação de <a href="https://ribafs.org" target="_blank">Ribamar FS</a></i>
</div>
<br>
</body>
</html>
