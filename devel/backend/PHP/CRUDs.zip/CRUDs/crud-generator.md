Alerta
São 4 exemplos com a intenção também de mostrar as mudanças deprocecdural para OO, mas o objetivo principal é o de oferecer um CRUD rápido para a manipulação das operações sobre os registros de uma tabela. Nada além disso. Caso queira algo com bons padrões de projeto e boas práticas sugiro procurar um bom framework, como o Laravel.

https://github.com/ribafs/crud-generator
