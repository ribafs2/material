# CRUD

Exemplo simples de CRUD com PHP usando PDO e Bootstrap, mas sem busca e paginação.

Baixei a versão 2.3.2 do bootstrap e criei os diretórios css e js para ele.

Crédito
https://www.startutorial.com/articles/view/php-crud-tutorial-part-1
