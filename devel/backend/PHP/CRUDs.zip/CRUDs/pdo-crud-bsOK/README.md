# PHP PDO CRUD Using MySQL Bootstrap Tutorial
Full CRUD Operations by using PHP , MySQL , Jquery , Ajax , JSON , PDO and Bootstrap
On following link step by step configuration is availble.
https://github.com/phpclicks/PDO-CRUD

#http://phpclicks.com/php-pdo-crud-tutorial/

You can also find some other PDO articles on http://phpclicks.com/?s=pdo
