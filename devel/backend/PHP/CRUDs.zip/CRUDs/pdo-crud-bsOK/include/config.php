<?php
$db_con = new PDO('mysql:host=localhost;dbname=estoque', 'root', 'mysql');
?>
