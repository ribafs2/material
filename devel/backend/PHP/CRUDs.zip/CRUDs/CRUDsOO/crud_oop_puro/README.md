Simple Create, Read, Update, Delete (CRUD) in PHP & MySQL using Object Oriented Programming (OOP)
========

A simple and basic system to add, edit, delete and view using PHP and MySQL using OOP.

Blog Article: [PHP: CRUD (Add, Edit, Delete, View) Application using OOP (Object Oriented Programming)](http://blog.chapagain.com.np/php-crud-add-edit-delete-view-application-using-oop-object-oriented-programming/)

SQL script to create database and tables is present in **database.sql** file.

