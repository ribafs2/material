<?php

//timezone

date_default_timezone_set('America/Fortaleza');

// conexão com o banco de dados

define('BD_SERVIDOR','localhost');
define('BD_USUARIO','root');
define('BD_SENHA','root');
define('BD_BANCO','testes');

