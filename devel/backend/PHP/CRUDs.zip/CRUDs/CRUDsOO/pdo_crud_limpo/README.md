# CRUD PHPOO

Adaptado do original em:

http://www.w3programmers.com/crud-with-pdo-and-oop-php/

## Como usar a classe pdoCrud():

- Criar o banco e entrar com ele na classe, vari�vel private $db="estoque";
- Ter em mente a estrutura da tabela com seus campos para entrar nos m�todos update e insertData
- Atualizer o c�digo dos arquivos index.php, insert.php e update.php, formul�rios e chamadas de m�todos

