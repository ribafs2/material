create table comments(
    id int primary key auto_increment,
    name varchar(255),
    comment text
);
