create table produtos(
    id int primary key auto_increment, 
    nome varchar(50), 
    tipo char(5), 
    criado_em date
);
