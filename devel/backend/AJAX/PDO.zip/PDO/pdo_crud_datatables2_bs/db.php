<?php

$username = 'root';
$password = 'root';
$connection = new PDO( 'mysql:host=localhost;dbname=testes', $username, $password );

?>
