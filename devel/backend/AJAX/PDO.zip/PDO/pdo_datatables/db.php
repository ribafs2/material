<?php

$username = 'root';
$password = 'root';
$connection = new PDO( 'mysql:host=localhost;dbname=fw-dnocs', $username, $password );

?>
