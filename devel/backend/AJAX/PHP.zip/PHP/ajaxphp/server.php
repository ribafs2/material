<?php
   $nome = $_POST["nome"];
   $email = $_POST["email"];
   $cpf = $_POST["cpf"];
   $nascimento = $_POST["nascimento"];
   echo $nome." - ".$email. ' - '.$cpf.' - '.$nascimento;
   //enter name and lastname into your form and onclick they will be alerted 
?>
