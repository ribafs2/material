<?php
namespace Ribafs\Laravel58Acl;

class Laravel58Acl
{
    // Build wonderful things
}
