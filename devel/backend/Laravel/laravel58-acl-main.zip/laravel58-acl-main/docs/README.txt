Para visualizar corretamente esta documentação estando em seu desktop abra no diretório web, exemplo:

http://localhost/laravel-acl/docs


