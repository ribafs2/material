<?php
namespace Ribafs\LaravelAcl;

class LaravelAcl
{
    // Build wonderful things
}
