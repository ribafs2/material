# Geradores de pacotes para laravel

É importante conhecer como funcionam e depois podemos usar um destes para facilitar a criação.

Eu gosto de tomar um pacotes de que gosto e alterá-lo ao meu gosto. Para mim isso é prático e tenho criado alguns assim. Depois de criar o primeiro os próximos ficam mais fáceis seguindo o modelo.

Este tem um gerador online, onde apenas preenchemos um form e ele gera o zip do pacote. E tem também para download

https://laravelpackageboilerplate.com/

https://github.com/melihovv/laravel-package-generator

https://packagecontrol.io/packages/Laravel%20Generator

https://getcraftable.com/

Tutorial

https://laravelpackage.com/

## Alguns pacotes que criei:

https://github.com/ribafs/laravel-crud-generator - este foi o primeiro. Criei um fork de outro do qual gostava e customizei

https://github.com/ribafs/laravel-acl (Este é para a versão 8 e implementa ACL em aplicativos. Tem versões para o 5.3, 6 e 7 com boa documentação)



