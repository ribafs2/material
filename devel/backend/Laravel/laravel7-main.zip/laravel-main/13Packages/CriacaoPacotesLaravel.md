# Criação de Pacotes Laravel

Uma forma de empacotar praticamente uma aplicação dentro do aplicativo laravel. Com este recurso tanto podemos empacotar um único command, como podemos empacotar controllers, models, views, rotas, providers, traits, etc. Como é o caso dos packages ribafs/laravel*-acl.


