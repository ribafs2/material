# Changelog

All notable changes to `mateusjunges/laravel-time-helpers` will be documented in this file.


## 1.0.1 - 2020-11-21
### Added
- Add `seconds` method to the TimeHelper class
### Fixed
- Fixed tests method names

## 1.0.0 - 2020-11-21
### Added
- `in()` function
- `past()` function