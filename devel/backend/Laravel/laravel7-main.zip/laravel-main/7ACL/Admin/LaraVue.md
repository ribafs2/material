# Package LaraVue

https://doc.laravue.dev/

composer create-project tuandm/laravue

cd laravue

php artisan migrate --seed

npm install && npm run dev

php artisan serve

localhost:8000

Já abre com email e senha salvos

Email: admin@laravue.dev 

Password: laravue

Opção?

Instalar laravel em laravue

cd laravue

composer require tuandm/laravue
