# Laravel Admin Panel Package

https://varbox.io/docs/2.x/installation

https://github.com/VarboxInternational/varbox

https://varbox.io/docs/2.x/full-example

Admin CRUD

ACL

Gerenciamento de conteúdo

Configurações

Gerenciador de notificações

Administração de credenciais

Multi language

Geo location

laravel new painel --jet --stack=livewire

cd painel

Criar e configurar banco (usando utf8mb4_unicode_ci)

.env

composer require varbox/varbox

php artisan varbox:install

php artisan migrate

php artisan db:seed --class="VarboxSeeder"

laravel:8000/admin/login

admin@mail.com

admin
