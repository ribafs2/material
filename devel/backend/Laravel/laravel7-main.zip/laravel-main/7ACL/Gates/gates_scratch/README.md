# Gates from scratch

Pequeno exemplo

Crie um aplicativo novo no laravel

Copie todos os arquivos desta papsta para o aplicativo criado mesclando e sobrescrevendo todos.

Então crie um banco e configure no .env

php artisan migrate

php artisan serve

http://localhost:8000


