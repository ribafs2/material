# Importando classes

Usamos use para importar classes pelo seu namespace:

use App\Models\User;
use App\Models\Client;

Forma resumida

use App\Models\{User,Client};


