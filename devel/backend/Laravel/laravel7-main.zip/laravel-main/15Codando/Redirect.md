# Redirect

return redirect('home');

return redirect::back()

return Redirect::to(URL::previous());

return redirect()->route('login');


