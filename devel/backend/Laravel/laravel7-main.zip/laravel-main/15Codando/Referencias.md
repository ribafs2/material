

https://www.larashout.com/a-complete-guide-to-laravel-storage

https://lovelaravel.com/understanding-and-working-with-files-in-laravel/


