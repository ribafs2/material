https://github.com/vsilva472/laravel-cpf

https://github.com/robersonfaria/validation

https://github.com/geekcom/validator-docs


