# Grid
```php
      <div class="row">
        <div class="col-sm-4">
          <h3>Column 1</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
          <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
        </div>
        <div class="col-sm-4">
          <h3>Column 2</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
          <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
        </div>
        <div class="col-sm-4">
          <h3>Column 3</h3>        
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
          <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
        </div>
      </div>
    </div>


    <!-- Grid básica -->
    <section>
    <div class="container">
        <h3>Grid básica</h3>
        <div class="row">
            <div class="col-sm-3 bg-dark">.col-sm-3</div>
            <div class="col-sm-3 bg-light">.col-sm-3</div>
            <div class="col-sm-3 bg-dark">.col-sm-3</div>
            <div class="col-sm-3 bg-light">.col-sm-3</div>
        </div>
        <br>
    </div>
    </section>

    <div class="row">
        <div class="col-md-6" style="padding:30px 50px;">
            <div class="container" style="padding:30px;border:1px solid gray;">
            <!-- FAQ Collapse -->
            </div>
        </div>
        <div class="col-md-6" style="padding:30px 50px;">
            <div class="container" style="padding:30px;border:1px solid gray;">
            <!-- Contact Form -->
            </div>
        </div>
    </div>
```

