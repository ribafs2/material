# Uso do float
```php
<div class="float-left">Float left on all viewport sizes</div><br>
<div class="float-right">Float right on all viewport sizes</div><br>
<div class="float-none">Don't float on all viewport sizes</div>

<div class="float-sm-left">Float left on viewports sized SM (small) or wider</div><br>
<div class="float-md-left">Float left on viewports sized MD (medium) or wider</div><br>
<div class="float-lg-left">Float left on viewports sized LG (large) or wider</div><br>
<div class="float-xl-left">Float left on viewports sized XL (extra-large) or wider</div><br>
```
## Todas as classes suportadas;
```php
    .float-left
    .float-right
    .float-none
    .float-sm-left
    .float-sm-right
    .float-sm-none
    .float-md-left
    .float-md-right
    .float-md-none
    .float-lg-left
    .float-lg-right
    .float-lg-none
    .float-xl-left
    .float-xl-right
    .float-xl-none
```
