# Após instalar liviewire ou inertia execute
```php
run npm install && npm run dev 
```
para a construção dos assets: javaScript e CSS necessários para os acima

