# Envio de e-mail

## Criar uma conta no gmail, caso não tenha uma a ser usada ou tenha e não queira usar

## Pegar dados do gmail

- Configurações
- Encaminhamento e POP/IMAP
- instruções de configuração
- host - smtp.gmai.com
- port - 587


```php
No .env
MAIL_HOST = smtp.gmai.com
MAIL_USERNAME = teste@gmail.com
MAIL_ENCRYPTION = tls
```

## Alterações das configurações de segurança/bloqueio

Contas e importação

Outras definições da Conta Google

Aplicações e sites associados

Permitir aplicações menos seguras - Ativar
  
