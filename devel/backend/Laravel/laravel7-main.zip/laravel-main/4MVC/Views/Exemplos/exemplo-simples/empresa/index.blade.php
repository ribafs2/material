@section('title')
  Trabalhando com Views no Laravel 7
@endsection

@extends('templates.master')

@section('header')
  <h1>Contabilidade</h1>
@endsection

@include('templates.content')
