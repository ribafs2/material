# BootStrap no Laravel 8

Para continuar usando bootstrap adicione para o método boot do AppServiceProvider

use Illuminate\Pagination\Paginator;

Adicionar ao método boot

Paginator::useBootstrap();

https://laravel.com/docs/8.x/pagination#using-bootstrap

