# Desabilitar o registro de novos usuários

Na versão 7 do laravel e anteriores

Na rota

Auth::routes(['register' => false]);

//Auth::routes();

