# Referências sobre comandos no Laravel

https://mattstauffer.com/blog/advanced-input-output-with-artisan-commands-tables-and-progress-bars-in-laravel-5.1/

https://medium.com/@flyingluscas/laravel-criando-comandos-904454cae849

https://appdividend.com/2017/09/21/laravel-5-5-artisan-console-tutorial/

https://ourcodeworld.com/articles/read/248/how-to-create-a-custom-console-command-artisan-for-laravel-5-3

https://laravelpackageboilerplate.com/#/


