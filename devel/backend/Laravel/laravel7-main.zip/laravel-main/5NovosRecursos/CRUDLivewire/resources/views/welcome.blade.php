<!DOCTYPE html>
<html lang="pt-br">
    <head>

        @livewireStyles

    </head>
    <body class="antialiased">
        <livewire:crud />


    @livewireScripts
    </body>
</html>
