# API no Laravel 8

API

Avatar - API Tokens

Create API Token

Após clicar em Create anotar o token - QLeNZZIAEliyvEFg5WJcZuFTxYgxBXzFTUmfbdH8

Abaixo tem um link para gerenciar as permissões - Permissions


