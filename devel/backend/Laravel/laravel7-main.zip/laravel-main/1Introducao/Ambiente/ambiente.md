# Requisitos do Laravel 8:

https://laravel.com/docs/8.x#server-requirements

