# Lagaron.org (c:\laragon\www)

## Alguns dos seus recursos

- notepad++, 
- composer, 
- cmdr, 
- git, 
- nodejs, 
- putty, 
- winscp, 
- telnet, 
- yarn, 
- adminer
- Podemos instalar outras versões do php
- Podemos instalar outra versão do mariadb

## Mais
- Cria automaticamente virtualhost para cada aplicação - pasta.dev
- Na opção criar rapidamente um website, pode criar: Joomla, Wordpress, Drupal, laravel, cakephp, symfony, lumen, etc

Use o Laragon q tem o NGROK.io integrado! Ele te da uma URL pública para seu amigo acessar o q vc está trabalhando. Vantagem de ver em tempo real as alterações e não ter todo aquele trabalho de colocar na hospedagem!

ngrok. Vc consegue liberar o local host para acesso externo. É bem simples de configurar e mais fácil ainda de usar. Usei recentemente num projeto. Recebi de um colega num grupo do Facebook.
