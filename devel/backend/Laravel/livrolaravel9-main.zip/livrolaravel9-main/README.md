# Livro Criação de aplicativos com laravel 9

Todo o material público que encontrei durante a elaboração do livro

Já o material que criei durante a elaboração é oferecido de forma restrita aos leitores no meu site.

- Estatisticas - Estatísticas diversas de áreas de TI
- Exemplos - 
	 -DataTables
	 -Git
	 -ckeditor.md
	 -Helper
- icons-ícones úteis tipo SVG
- 1GitHub.odt - Tutorial para cadastro de conta no Github
- 2RepositorioGH.odt - Tutorial para criação de repositório no Github
- 3ChaveSSH.odt - Tutorial para criação de chave do SSH e punlicação no Github
- 4GithubDesktop.odt - Usando o Github Desktop
- empresas-que-usam-laravel-no-brasil.md
- História dos computadores.odt
- Laravel9UsersRolesPermissions.odt
- LaravelHistoria.odt
- LaravelTools.md
- nano - Pequeno tutorial sobre o uso do editor nano para o terminal
- nanoforwindows
- Packages - Pequeno tutorial sobre a criação de um fork
- Postgres - Pequeno tutorial sobre a configuração do PostgreSQL
- Scripts - Criação de scripts no Linux
- simple-bootstrap-5-dashboard.zip - Pequeno dashboard usando o Bootstrap 5

## Sobre o Livro

[Indice do Livro](indice.pdf)

Caso esteja interessado entre em contato pelo ribafs@gmail.com
