# The license

Copyright (c) Ribamar FS <ribafs@gmail.com>

MIT
