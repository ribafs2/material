Para visualizar corretamente esta documentação abra no diretório web, exemplo:

http://localhost/laravel-acl-exist/docs


