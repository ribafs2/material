<?php
namespace Ribafs\LaravelAclExist;

class LaravelAclExist
{
    // Build wonderful things
}
