## Artisan GUI

Executar comandos artisan via web

https://github.com/inFureal/artisan-gui

composer require infureal/artisan-gui

php artisan vendor:publish --provider="Infureal\Providers\GuiServiceProvider"

php artisan serve

http://localhost:8000/~artisan


