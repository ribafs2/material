# Segurança em 2 fatores no Laravel 8

2-factor

Para habilitar - Profile - Two Factor Authentication - Enable

Capturar os códigos abaixo do QRCode e guardar para configurações futuras.

Para recuperar o 2-factor usar a última linha guardada acima (Use a recovery code)

Para recuperar uma segunda vez usar a primeira linha

