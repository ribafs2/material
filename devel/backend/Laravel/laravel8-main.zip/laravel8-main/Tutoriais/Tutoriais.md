# Tutoriais sobre Laravel 8

- https://laravel.com/docs/8.x

- https://blog.laravel.com/

- https://laravel-docs-pt-br.readthedocs.io/en/latest/

- https://www.tutsmake.com/category/laravel-tutorial/

- https://www.itsolutionstuff.com/tag/laravel-8.html

- https://www.itsolutionstuff.com/tag/laravel-7.html

- https://laravel-news.com/

- https://kinsta.com/pt/blog/tutoriais-laravel/

- https://dev.to/takunda/creating-laravel-desktop-apps-part-1-setup-1le3

- https://www.techiediaries.com/laravel-8/

- https://spdload.com/blog/best-laravel-tools-and-resources/

- https://quickadminpanel.com/blog/course-lesson-1-laravel-and-default-auth/

- https://laravelplayground.com/#/

- https://www.tutorialspoint.com/laravel/index.htm

- https://www.studentstutorial.com/laravel/laravel-tutorial

- https://dev.to/ericnanhu/laravel-tutorial-for-beginners-laravel-8-edition-1nl0

- https://www.javatpoint.com/laravel

- https://www.phptpoint.com/laravel-introduction/

- https://kinsta.com/blog/laravel-tutorial/

- https://www.softwaretestinghelp.com/php-laravel-tutorial-for-beginners/

- https://www.guru99.com/laravel-tutorial.html

- https://welldoneby.com/blog/laravel-tutorial-for-beginners/

- https://www.w3schools.in/laravel-tutorial/


