https://github.com/qirolab/laravel-fortify-example
