# Sobre as actions

As ações/actions são como o controle de versão do seu processo de migração, permitindo que sua equipe modifique e compartilhe o esquema acionável do aplicativo. Se você já teve que dizer a um colega de equipe para executar manualmente qualquer ação em um servidor de produção, você se deparou com um problema que as ações resolvem.

https://github.com/andrey-helldar/laravel-actions

