

https://github.com/gentritabazi01/Clean-Laravel-Api

https://www.techiediaries.com/laravel-8-rest-api-crud-mysql/ 

https://www.itsolutionstuff.com/post/laravel-8-rest-api-with-passport-authentication-tutorialexample.html?ref=laravelnews
https://github.com/savanihd/Laravel-8-Rest-API-with-Passport 


