# Controllers no Laravel 8

Pelo que sei até o momento a versão 8 do Laravel praticamente não alterou os controllers.


