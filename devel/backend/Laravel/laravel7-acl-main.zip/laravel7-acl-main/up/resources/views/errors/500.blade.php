@include('errors.layout')
        <h3 align="center">500 - has gone wrong on the web site's server</h3>
    </div>
