<?php
namespace Ribafs\Laravel7Acl;

class Laravel7Acl
{
    // Build wonderful things
}
