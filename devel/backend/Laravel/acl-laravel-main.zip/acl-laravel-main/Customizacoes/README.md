# Customizações

Aqui mostro como:

- Adicionar um novo CRUD

- Adicionar uma role

- Adicionar um novo user

- Configurar o cache


