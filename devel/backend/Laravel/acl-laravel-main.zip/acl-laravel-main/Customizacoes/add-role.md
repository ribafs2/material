# Adicionar uma role

Também podemos precisar adicionar uma nova roe com permissões diferentes, para que abrigue novos usuários

Também aqui basicamente precisamos alterar a seeder Permissions. Na dúvida confira o exemplo acl-final10-crudrole   

Vamos adicionar a role compras
purchase com products

E dentro dela products

Ajustar o menu

Ajustar a rota

Ajustar o controller products
