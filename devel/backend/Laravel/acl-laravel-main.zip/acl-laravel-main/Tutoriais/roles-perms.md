## Roles e permissioons

Roles
Permissions

Veja as permissões que cada role tem

suuper: all-all

admin: users-all, roles-all e permissions-all

manager - clients-all

user - clients-index

Em detalhes

super - tem total permissão sobre todo o aplicativo

admin - tem total permissão sobre users, roles e permissions

manager - total permissão sobre clients

user - permissão apenas sobre clients-index


