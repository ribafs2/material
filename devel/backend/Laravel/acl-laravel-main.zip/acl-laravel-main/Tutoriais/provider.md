## O provider PermissionsServiceProvider

app/Providers/PermissionsServiceProvider.php

A definição das tags customizadas do blade surgiu no provider abaixo
Usando nas blades


@role
@endrole

Que deverão ser usadas nas blades
Para uso nos controllers e routes temos:

- super:role
- admin:role
- etc

