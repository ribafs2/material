<?php
namespace Ribafs\Laravel6Acl;

class Laravel6Acl
{
    // Build wonderful things
}
