# CodeIgniter 4 Login & Register
CodeIgniter 4 Login &amp; Register System based on YouTube tutorial 
> https://www.youtube.com/watch?v=uYX9FLi1BYg&list=PLYogo31AXFBONHR0WjlnhxN4ulRrF98aA
## 1. Setup
Change .env settings to apply to your environment

## 2. Run migration
Open terminal and navigate to your project folder, then run:
> php spark migrate 

This will create the table 'users' in your database that you secified in your .env file

### 3. Now you can Register your first user
