# Curso de Codeigniter para iniciantes  
## RBtech (Ricardo Bernardi)  

### Lista de aulas - [Vídeos do curso](https://www.youtube.com/watch?v=0YE2xAC1GsU&list=PLInBAd9OZCzz2vtRFDwum0OyUmJg8UqDV)

Aula 01 - Introdução e instalação  
Aula 02 - MVC e a estrutura de diretórios  
Aula 03 - MVC na prática  
Aula 04 - Criando um site parte 1  
Aula 05 - Criando um site parte 2  
Aula 06 - Criando um site parte 3  
Aula 07 - Criando um painel parte 1  
Aula 08 - Criando um painel parte 2  
Aula 09 - Criando um painel parte 3  
Aula 10 - Criando um painel parte 4  
Aula 11 - Criando um painel parte 5  
Aula 12 - Criando um painel parte 6  