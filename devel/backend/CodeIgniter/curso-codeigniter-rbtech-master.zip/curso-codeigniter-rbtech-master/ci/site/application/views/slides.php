<section id="gallery">
<div class="container">
	<ul id="myRoundabout">
	<li><img src="<?= base_url('assets/images/slide3.jpg'); ?>" alt=""></li>
	<li><img src="<?= base_url('assets/images/slide2.jpg'); ?>" alt=""></li>
	<li><img src="<?= base_url('assets/images/slide5.jpg'); ?>" alt=""></li>
	<li><img src="<?= base_url('assets/images/slide1.jpg'); ?>" alt=""></li>
	<li><img src="<?= base_url('assets/images/slide4.jpg'); ?>" alt=""></li>
  </ul>
</div>
</section>

