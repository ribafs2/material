<section id="content">
<article>
	<h2>Welcome to <span>Our Design Company!</span></h2>
  <p>Design Company is a free web template created by TemplateMonster.com team. This website template is optimized for 1024X768 screen resolution. It is also HTML5 &amp; CSS3 valid.</p>
  <figure><a href="#"><img src="<?= base_url('assets/images/banner1.jpg'); ?>" alt=""></a></figure>
  <p>This website template has several pages: <a href="<?= base_url('home'); ?>">Home</a>, <a href="<?= base_url('about'); ?>">About us</a>, <a href="<?= base_url('privacy'); ?>">Privacy Policy</a>, <a href="<?= base_url('gallery'); ?>">Gallery</a>, <a href="<?= base_url('contacts'); ?>">Contact us</a> (note that contact us form – doesn’t work), <a href="<?= base_url('sitemap'); ?>">Site Map</a>.</p>
  This website template can be delivered in two packages - with PSD source files included and without them. If you need PSD source files, please go to the template download page at TemplateMonster to leave the e-mail address that you want the template ZIP package to be delivered to.
</article> 
</section>
