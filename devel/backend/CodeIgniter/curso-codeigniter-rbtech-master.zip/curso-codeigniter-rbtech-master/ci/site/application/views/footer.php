<footer>
    <div class="container">
        <div class="wrapper">
            <div class="fleft">Copyright - <?= date('Y'); ?> - Design Company</div>
            <div class="fright"><a rel="nofollow" href="http://www.templatemonster.com/" target="_blank">Website template</a> designed by TemplateMonster.com&nbsp; &nbsp; |&nbsp; &nbsp; <a href="http://templates.com/product/3d-models/" target="_blank">3D Models</a> provided by Templates.com</div>
        </div>
    </div>
</footer>

<script type="text/javascript"> Cufon.now();</script>

</body>
</html>
