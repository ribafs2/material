# CodeIgniter 4 Framework

[Codeigniter 4 CRUD with Bootstrap and MySQL Example](https://www.positronx.io/codeigniter-crud-with-bootstrap-and-mysql-example/).