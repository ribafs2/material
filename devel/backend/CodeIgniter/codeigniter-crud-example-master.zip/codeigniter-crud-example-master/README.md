# codeigniter-crud-example
Create CRUD operations in Codeigniter 4 application. We will also shed light on how to integrate Bootstrap 4 and display data using Datatables jQuery plug-in.

[Codeigniter 4 CRUD with Bootstrap and MySQL Example](https://www.positronx.io/codeigniter-crud-with-bootstrap-and-mysql-example/)