# escrever-nome-por-extenso
Script PHP capaz de escrever números por extenso
