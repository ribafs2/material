# Escrever número por extenso

Script PHP capaz de escrever números por extenso em PHP
