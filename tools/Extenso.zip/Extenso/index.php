<?php require_once 'header.php'; ?>

  <h2>Escrever um número por extenso</h2>
  <form action="./extenso.php" method="POST">
    <div class="form-group">
      <label for="number">Número:</label>
      <input type="number" class="form-control" id="number" placeholder="Entre um número inteiro" name="number">
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
</div>

</body>
</html>

