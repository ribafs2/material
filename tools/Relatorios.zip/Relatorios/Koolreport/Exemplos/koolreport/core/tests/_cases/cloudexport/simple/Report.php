<?php

class Report extends \koolreport\KoolReport
{
    use \koolreport\clients\Bootstrap;
    use \koolreport\cloudexport\Exportable;
}