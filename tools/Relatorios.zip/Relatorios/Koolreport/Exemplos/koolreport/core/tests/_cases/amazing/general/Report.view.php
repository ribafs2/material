<html>
    <head>
        <title>Test Amazing Theme</title>
    </head>
    <body>
        <h1>Test Amazing Theme</h1>
    </body>
</html>