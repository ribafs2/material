<?php
require_once "Report.php";

$report = new Report;
$report->run()->render();
