<?php

require_once "../../DbReport.php";

class Report extends DbReport
{
    use \koolreport\bootstrap3\Theme;
}