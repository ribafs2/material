<?php
require_once "../../../../autoload.php";

require_once "../../DbReport.php";

class Report extends DbReport
{
    use \koolreport\amazing\Theme;
}