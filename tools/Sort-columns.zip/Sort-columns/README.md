# Sort columns

Como ordenar colunas de uma tabela com duas alternaticas:

- MySQLi

- PDO


