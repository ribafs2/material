<?php

$host = "localhost"; /* Host name */
$user = "root"; /* User */
$pass = "root"; /* Password */
$dbname = "testes"; /* Database name */

//$con = mysqli_connect($host, $user, $password,$dbname);
$con = new PDO('mysql:host='.$host.';dbname='.$dbname, $user, $pass);
// Check connection
if (!$con) {
	die("Connection failed: " . mysqli_connect_error());
}
