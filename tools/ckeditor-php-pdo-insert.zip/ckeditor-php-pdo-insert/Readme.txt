Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: yogesh@makitweb.com
Tutorial Link: https://makitweb.com/integrate-ckeditor-to-html-page-and-save-to-mysql-with-php/

#######################################################

### Instructions - 

* Import attached content.sql file in your MySQL database.
* Update database connection in config.php file.