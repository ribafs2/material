## No Linux Mint os snippets devem ser copiados para a pasta:

~/.config/Code/User/snippets

## No Windows para

c:\Users\
