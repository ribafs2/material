# Dicas de uso da extensão emmet

No VSCode ela é uma extensão nativa e não de terceiros

## HTML

## Teclas de atalho

Antes alterei em Settings:

Editor: Multi Cursor Modifier para:

ctrlCmd

## Selecionar várias linhas simultâneas para inserir algo ou remover em todas:

Shift+Alt+seta (para cima ou para baixo)

## Selecionar linhas alternadas

Clicar na primeira, segurar o Ctrl e clicar nas outras. Ou selecionar, exemplo, <li>, teclar Ctrl+D para selecionar o próximo <li>

.primeiro

<div class="primeiro"></div>

.primeiro.segundo

<div class="primeiro segundo"></div>

lorem

ul>li*5>a{link$}
```php
    <ul>
        <li><a href="">link1</a></li>
        <li><a href="">link2</a></li>
        <li><a href="">link3</a></li>
        <li><a href="">link4</a></li>
        <li><a href="">link5</a></li>
    </ul>
```

input:text.nome#nome - <input type="text" name="" id="nome" class="nome">

div[item=$]*10
```php
<div item="1"></div>
<div item="2"></div>
<div item="3"></div>
<div item="4"></div>
<div item="5"></div>
<div item="6"></div>
<div item="7"></div>
<div item="8"></div>
<div item="9"></div>
<div item="10"></div>
```
div[class="item$"]*10
```php
<div class="item1"></div>
<div class="item2"></div>
<div class="item3"></div>
<div class="item4"></div>
<div class="item5"></div>
<div class="item6"></div>
<div class="item7"></div>
<div class="item8"></div>
<div class="item9"></div>
<div class="item10"></div>

div[class="item$"]*10{item$}

<div class="item1">item1</div>
<div class="item2">item2</div>
<div class="item3">item3</div>
<div class="item4">item4</div>
<div class="item5">item5</div>
<div class="item6">item6</div>
<div class="item7">item7</div>
<div class="item8">item8</div>
<div class="item9">item9</div>
<div class="item10">item10</div>
```

## CSS
```php
pos: position: relative;
d: display: block;
m: margin: ;
mt: margin-top: ;
mb: margin-bottom: ;
pw: padding-top: ;
pb: padding-bottom: ;
bg: background: #000;
bgc: background-color: #fff;
!: !important
@m: @media screen {}
c: color: #000;
op: opacity: ;
```
Mover o cursor do mouse sobre o código de uma cor para abrir o seletor de cores. Mover e clicar sobre certa cor para recebê-la na propriedade;

https://docs.emmet.io/cheat-sheet/

https://code.visualstudio.com/docs/editor/emmet

Completa o caminho de qualquer arquivo em links, scripts, imagens após digitarmos o início.

