# Como Selecionar uma coluna vertical em um texto

Para poder remover toda a coluna ou efetual outras transformações com ela:

- Selecione a largura que deseja com o mouse ou com as setas
- Selection
- Caso não esteja ticado marque 
    Column Selecion Mode
- Então prenda o Shift e mova com a seta para baixo
- Agora poderá teclar Delete para remover a seleção



