<?php 

class DirList{
	public static function List($Dir, $File, $Self){
		$filename = str_replace($Dir."/", "", $File);
		echo '<!DOCTYPE html>
		<html>
		<head>
		<style type=\'text/css\'>
				body       {background-color:#1b1b1b; color:#CCCCCC; font-family: \'Courier New\', Courier, monospace; font-size: 14pt; padding:5px;}
				h2         {margin-bottom: 12px;}
				a, a:active {text-decoration: none; color:#009E99;}
				a:visited   {color: #007070;}
				a:hover, a:focus {text-decoration: none; color:#CCCCCC;}
				a img		{border:none;}
				table      { }
				th, td     { text-align:left; }
				th         { font-weight: bold; padding-right: 16px; padding-bottom: 3px;}
				td         {padding-right: 18px;}
				td.s, th.s {text-align: right;}
		    	.kanan {text-align: left;padding-left:100px;}
		</style>
		</head>
		<body><center>
		<h1>RibaFS</h1><hr><table>';
		$scan = array_diff(scandir($Dir), array('.', $filename));
		foreach ($scan as $list) {
			if($list == "style.class.php" || $list == "index.php") continue;
			echo "<tr><td><a href='$list'>$list</a></td></tr>";
		}
		echo "</table>
		    <hr> <address> Created by <a href='https://fb.com/florienzh4x' target='_blank'>Florienzh4x</a></address></body></html>";	
	}
}
